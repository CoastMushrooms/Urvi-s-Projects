import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class funny extends JPanel implements KeyListener
{
  JFrame frame;
  boolean gameOn = true;
  boolean gameWin = false;
  boolean showWin = true;
  int [][] grid;
  boolean jOver = false;
  int timer;
  int score = 0;
  
  public funny()
  {
    frame = new JFrame("2048");
    frame.add(this);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(650, 650);
    frame.addKeyListener(this);
    
    setupGrid();
    repaint(); //replacement for paintComponent(Graphics g)
    
    frame.setVisible(true);
  }
  
  public void paintComponent(Graphics g)
  {
    super.paintComponent(g); //clears screen
    g.setColor(Color.PINK);
    g.fillRect(0, 0, frame.getHeight(), frame.getWidth());
    
    g.setFont(new Font("TimesRoman", Font.BOLD, 100));
    Graphics2D g2 = (Graphics2D) g;
    g2.setStroke(new BasicStroke(5));
    
    g.setColor(Color.WHITE);
  
    for(int row = 0; row < grid.length; row++)
    {
      for(int col = 0; col < grid[0].length; col++)
      {
      g.drawRect(col * 100 + 100, row * 100 + 100, 100, 100);
      }
    }
  
    for(int row = 0; row < grid.length; row++)
    {
      for(int col = 0; col < grid[0].length; col++)
      {
        g.setColor(Color.WHITE);
        g.setFont(new Font("TimesRoman", Font.BOLD, 50));
        g2.drawRect(col*100 + 100, row*100 + 100, 100, 100);
        int value = grid[row][col];
        
        g.setColor(colorPick(value));
        g.fillRect(col * 100 + 100, row * 100 + 100, 100, 100);
        g.setColor(new Color(255, 255, 255));
        
        g.setColor(new Color(255, 255, 255));
        g.setFont(new Font("TimesRoman", Font.BOLD, 50));
        g.drawString("Score: " + score, 30, 70);
          
        if(value > 999)
        {
          g.setFont(new Font("TimesRoman", Font.BOLD, 40));
          g.drawString("" + grid[row][col], col * 100 + 105, row * 100 + 167);
        }
        else if(value > 99)
        {
          g.drawString("" + grid[row][col], col * 100 + 108, row * 100 + 170);
        }
        else if(value > 9)
        {
          g.drawString("" + grid[row][col], col * 100 + 123, row * 100 + 170);
        }
        else if(value > 0)
        {
          if(value < 8)
          {
            g.setColor(new Color(255, 255, 255));
          }
        g.drawString("" + grid[row][col], col * 100 + 135, row * 100 + 170);
        } 
      }
    }
  
    if(!gameOn)
    {
      g.setColor(new Color(77, 9, 34));
      g.setFont(new Font("TimesRoman", Font.BOLD, 90));
      g.drawString("GAME OVER!!", 10, 300);
      g.setFont(new Font("TimesRoman", Font.BOLD, 50));
      g.drawString("\"R\" to restart.", 130, 400);
      score = 0;
    }
  
    if(gameWin && showWin)
    {
      g.setColor(new Color(77, 9, 34));
      g.setFont(new Font("TimesRoman", Font.BOLD, 90));
      g.drawString("YOU WIN!!", 70, 300);
      g.setFont(new Font("TimesRoman", Font.BOLD, 50));
      showWin = false;
    }
  
    if(jOver)
    {
      g.setColor(Color.RED);
      g.setFont(new Font("TimesRoman", Font.BOLD, 50));
      g.drawString("Warning: It's Jover", 60, 300);
      g.drawString("Turns left: " + timer, 120, 390);
    }
  }
  
  public Color colorPick(int num)
  {
    if(num == 2)
    {
      return new Color(128, 237, 217);
    }
    if(num == 4)
    {
      return new Color(128, 226, 237);
    }
    if(num == 8)
    {
      return new Color(128, 210, 237);
    }
    if(num == 16)
    {
      return new Color(128, 186, 237);
    }
    if(num == 32)
    {
      return new Color(128, 166, 237);
    }
    if(num == 64)
    {
      return new Color(128, 133, 237);
    }
    if(num == 128)
    {
      return new Color(170, 128, 237);
    }
    if(num == 256)
    {
      return new Color(197, 128, 237);
    }
    if(num == 512)
    {
      return new Color(215, 128, 237);
    }
    if(num == 1024)
    {
      return new Color(237, 128, 197);
    }
    if(num == 2048)
    {
      return new Color(255, 166, 206);
    }
    
    return new Color(250, 192, 213);
  }
  
  public void keyPressed(KeyEvent e)
  {
    if(!gameOn)
    {
      if(e.getKeyCode() == 82)
      {
        gameOn = true;
        setupGrid();
        showWin = true;
        gameWin = false;
      }
    }
  
    int[][] gridC = copy();
    
    if(e.getKeyCode() == 37)
    {
      slideLeft();
    }
    
    if(e.getKeyCode() == 38)
    {
      slideUp();
    }
    
    if(e.getKeyCode() == 39)
    {
      slideRight();
    }
    
    if(e.getKeyCode() == 40)
    {
      slideDown();
    }
    
    if(!match(gridC))
    {
      addNumber();
    }
    
    if(!canMove())
    {
      gameOn = false;
    }
    
    repaint();
  }
  
  public boolean canMove()
  {
    for(int row = 0; row < grid.length; row++)
    {
      for(int col = 0; col < grid[0].length; col++)
      {
        int value = grid[row][col];
    
        if(value == 0)
        {
          return true;
        }
    
        if(row > 0)
        {
          if(grid[row - 1][col] == value || grid[row - 1][col] == 0)
          {
    return true;
          }
        }
        
        if(row < grid.length-1)
        {
          if(grid[row + 1][col] == value || grid[row + 1][col] == 0)
          {
            return true;
          }
        }
  
        if(col > 0)
        {
          if(grid[row][col - 1] == value || grid[row][col - 1] == 0)
          {
            return true;
          }
        }
        
        if(col < grid[0].length-1)
        {
          if(grid[row][col + 1] == value || grid[row][col + 1] == 0)
          {
            return true;
          }
        }
      }
    }
    return false;
  }
  
  public boolean match(int [][] a)
  {
    for(int row = 0; row < grid.length; row++)
    {
      for(int col = 0; col < grid[0].length; col++)
      {
        if(a[row][col] != grid[row][col])
        {
          return false;
        }
      }
    }
    return true;
  }
  
  public int[][] copy()
  {
    int [][] copy = new int[6][6];
    
    for(int row = 0; row < grid.length; row++)
    {
      for(int col = 0; col < grid[0].length; col++)
      {
        copy[row][col] = grid[row][col];
      }
    }
    return copy;
  }
  
  public void slideLeft()
  {
    for(int row = 0; row < grid.length; row++)
    {
      for(int col = 0; col < grid[0].length; col++)
      {
        int searchCol = col;
        searchCol++;
        int found1 = grid[row][col];
        while(found1 == 0 && searchCol <= grid[0].length - 1)
        {
          found1 = grid[row][searchCol];
          grid[row][searchCol] = 0;
          searchCol++;
        }
  
        int found2 = 0;
        if(searchCol <= grid[0].length - 1)
        {
          found2 = grid[row][searchCol];
        }
  
        while(found2 == 0 && searchCol <= grid[0].length - 2)
        {
          searchCol++;
          found2 = grid[row][searchCol];
        }
  
        if(found1 == found2)
        {
          grid[row][col] = found1 + found2;
          
          score += (found1+found2);
          
          if(found1 + found2 == 2048)
          {
            gameWin = true;
          }
          
          if(searchCol <= grid[0].length - 1)
          {
            grid[row][searchCol] = 0;
          }
        }
        else
        {
          grid[row][col] = found1;
        }
      }
    }
  }
  
  public void slideUp()
  {
    for(int col = 0; col < grid[0].length; col++)
    {
      for(int row = 0; row < grid.length; row++)
      {
        int searchRow = row;
        searchRow++;
        int found1 = grid[row][col];
        while(found1 == 0 && searchRow <= grid.length - 1)
        {
          found1 = grid[searchRow][col];
          grid[searchRow][col] = 0;
          searchRow++;
        }
  
        int found2 = 0;
        if(searchRow <= grid.length - 1)
        {
          found2 = grid[searchRow][col];
        }
        
        while(found2 == 0 && searchRow <= grid.length - 2)
        {
          searchRow++;
          found2 = grid[searchRow][col];
        }
        
        if(found1 == found2)
        {
          grid[row][col] = found1 + found2;
        
          score += (found1+found2);
        
          if(found1 + found2 == 2048)
          {
            gameWin = true;
          }
          
          if(searchRow <= grid.length - 1)
          {
            grid[searchRow][col] = 0;
          }
        }
        else
        {
          grid[row][col] = found1;
        }
      }
    }
  }
  
  public void slideRight()
  {
    for(int row = 0; row < grid.length; row++)
    {
      for(int col = grid[0].length - 1; col >= 0; col--)
      {
        int searchCol = col;
        searchCol--;
        int found1 = grid[row][col];
        while(found1 == 0 && searchCol >= 0)
        {
          found1 = grid[row][searchCol];
          grid[row][searchCol] = 0;
          searchCol--;
        }
      
        int found2 = 0;
        if(searchCol >= 0)
        {
          found2 = grid[row][searchCol];
        }
      
        while(found2 == 0 && searchCol >= 1)
        {
          searchCol--;
          found2 = grid[row][searchCol];
        }
      
        if(found1 == found2)
        {
          grid[row][col] = found1 + found2;
          
          score += (found1+found2);
          
          if(found1 + found2 == 2048)
          {
            gameWin = true;
          }
          
          if(searchCol >= 0)
          {
            grid[row][searchCol] = 0;
          }
        }
        else
        {
        grid[row][col] = found1;
        }
      }
    }
  }
  
  public void slideDown()
  {
    for(int col = 0; col < grid[0].length; col++)
    {
      for(int row = grid.length - 1; row >= 0; row--)
      {
        int searchRow = row;
        
        int found1 = grid[row][col];
        searchRow--;
        while(found1 == 0 && searchRow >= 0)
        {
          found1 = grid[searchRow][col];
          grid[searchRow][col] = 0;
          searchRow--;
        }
        
        int found2 = 0;
        if(searchRow >= 0)
        {
          found2 = grid[searchRow][col];
        }
        
        while(found2 == 0 && searchRow >= 1)
        {
          searchRow--;
          found2 = grid[searchRow][col];
        }
        
        if(found1 == found2)
        {
          grid[row][col] = found1 + found2;
          
          score += (found1+found2);
          
          if(found1 + found2 == 2048)
          {
            gameWin = true;
          }
          
          if(searchRow >= 0)
          {
            grid[searchRow][col] = 0;
          }
        }
        else
        {
          grid[row][col] = found1;
        }
      }
    }
  }
  
  public void addNumber()
  {
    int fate = (int)(Math.random()*100 + 1);
    
    if(fate == 100 && !jOver)
    {
      jOver = true;
      timer = 3;
    }
    
    if(!jOver)
    {
      int random = (int)(Math.random()*4 + 1);
      
      if(random <= 3)
      {
        int ranRow = (int)(Math.random()*6);
        int ranCol = (int)(Math.random()*6);
        while(grid[ranRow][ranCol] != 0)
        {
        ranRow = (int)(Math.random()*6);
        ranCol = (int)(Math.random()*6);
        }
        grid[ranRow][ranCol] = 2;
      }
    
      if(random == 4)
      {
        int ranRow = (int)(Math.random()*6);
        int ranCol = (int)(Math.random()*6);
        while(grid[ranRow][ranCol] != 0)
        {
          ranRow = (int)(Math.random()*6);
          ranCol = (int)(Math.random()*6);
        }
        
        grid[ranRow][ranCol] = 4;
        }
      }
  
    if(jOver)
    {
      int over = (int)(Math.random()*10 + 1);
      
      if(timer <= 0)
      {
        jOver = false;
      }
      
      if(over == 1)
      {
        int overRow = (int)(Math.random()*6);
        int overCol = (int)(Math.random()*6);
        while(grid[overRow][overCol] != 0)
        {
          overRow = (int)(Math.random()*6);
          overCol = (int)(Math.random()*6);
        }
        grid[overRow][overCol] = 2;
      }
      
      if(over == 2)
      {
        int overRow = (int)(Math.random()*6);
        int overCol = (int)(Math.random()*6);
        while(grid[overRow][overCol] != 0)
        {
          overRow = (int)(Math.random()*6);
          overCol = (int)(Math.random()*6);
        }
        grid[overRow][overCol] = 4;
      }
      
      if(over == 3)
      {
        int overRow = (int)(Math.random()*6);
        int overCol = (int)(Math.random()*6);
        while(grid[overRow][overCol] != 0)
        {
          overRow = (int)(Math.random()*6);
          overCol = (int)(Math.random()*6);
        }
        grid[overRow][overCol] = 8;
      }
      
      if(over == 4)
      {
        int overRow = (int)(Math.random()*6);
        int overCol = (int)(Math.random()*6);
        while(grid[overRow][overCol] != 0)
        {
          overRow = (int)(Math.random()*6);
          overCol = (int)(Math.random()*6);
        }
        grid[overRow][overCol] = 16;
      }
      
      if(over == 5)
      {
        int overRow = (int)(Math.random()*6);
        int overCol = (int)(Math.random()*6);
        while(grid[overRow][overCol] != 0)
        {
          overRow = (int)(Math.random()*6);
          overCol = (int)(Math.random()*6);
        }
        grid[overRow][overCol] = 32;
      }
      
      if(over == 6)
      {
        int overRow = (int)(Math.random()*6);
        int overCol = (int)(Math.random()*6);
        while(grid[overRow][overCol] != 0)
        {
          overRow = (int)(Math.random()*6);
          overCol = (int)(Math.random()*6);
        }
        grid[overRow][overCol] = 64;
      }
      
      if(over == 7)
      {
        int overRow = (int)(Math.random()*6);
        int overCol = (int)(Math.random()*6);
        while(grid[overRow][overCol] != 0)
        {
          overRow = (int)(Math.random()*6);
          overCol = (int)(Math.random()*6);
        }
        grid[overRow][overCol] = 128;
      }
      
      if(over == 8)
      {
        int overRow = (int)(Math.random()*6);
        int overCol = (int)(Math.random()*6);
        while(grid[overRow][overCol] != 0)
        {
          overRow = (int)(Math.random()*6);
          overCol = (int)(Math.random()*6);
        }
        grid[overRow][overCol] = 256;
      }
      
      if(over == 9)
      {
        int overRow = (int)(Math.random()*6);
        int overCol = (int)(Math.random()*6);
        while(grid[overRow][overCol] != 0)
        {
          overRow = (int)(Math.random()*6);
          overCol = (int)(Math.random()*6);
        }
        grid[overRow][overCol] = 512;
      }
      
      if(over == 10)
      {
        int overRow = (int)(Math.random()*6);
        int overCol = (int)(Math.random()*6);
        while(grid[overRow][overCol] != 0)
        {
          overRow = (int)(Math.random()*6);
          overCol = (int)(Math.random()*6);
        }
        grid[overRow][overCol] = 1024;
      }
    timer--;
    }
  }
  
  public void setupGrid()
  {
    grid = new int[6][6];
    addNumber();
  }
  
  public void keyTyped(KeyEvent e)
  {
  
  }
  
  public void keyReleased(KeyEvent e)
  {
  
  }

  public static void main(String [] args)
  {
    funny run = new funny();
  }
}