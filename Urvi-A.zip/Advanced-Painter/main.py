# Author: Urvi Akhouri
# Program Name: Advanced Room Painter Project
# Description: The purpose of this project is to calculate the room painting cost
# Date: 03/21/23
# Version: 1.0

def paintCost(paint):
    if paint == 1:
        paintCost = 0.5
    elif paint == 2:
        paintCost = 0.75
    elif paint == 3:
        paintCost = 1.25
    elif paint == 4:
        paintCost = 1.75
    elif paint == 5:
        paintCost = 2.50
    else:
        print("The highest quality paint has been automatically chosen.")
        paintCost = 2.50
    return paintCost


# function to calculate pricing of the paint job
def totalCost(paintCost, length, height, width, windows, doors):
    # lambdas to calculate area cost of room and ceiling
    areaCost = lambda length, height, width, windows, doors: ((2 * (length * height + width * height)) - (
            windows * 12 + doors * 20)) / 2
    ceilCost = lambda length, width: (length * width) / 4
    subtotal = paintCost(paint) * areaCost(length, height, width, windows, doors) + paintCost(paint) * ceilCost(length, width)
    trim = windows * 2 + doors * 3
    total = subtotal + trim
    return total

roomNum = 1

# numbers of rooms to paint
rooms = int(input("How many rooms would you like to paint: "))
# total cost counter
allCost = 0
# counter variable
counter = 0
# while loop to calculate cost
while counter < rooms:
    # user inputs information needed for calculations
    length = float(input("What is the room's length: "))
    width = float(input("What is the room's width: "))
    height = float(input("What is the room's height: "))
    windows = float(input("How many windows are in the room: "))
    doors = float(input("How many doors are in the room: "))
    # choice to decide what paint type to paint with
    paint = float(input("What type of paint would you like to paint with?\n\n"
                        "1. Flat/Matte ($0.50 per square foot)\n"
                        "2. Eggshell ($0.75 per square foot)\n"
                        "3. Satin ($1.25 per square foot)\n"
                        "4. Semi-Gloss ($1.75 per square foot)\n"
                        "5. High-Gloss ($2.50 per square foot)\n\n"
                        "Enter the price you choose here (Numbers Only): "))
    paintTotal = paintCost(paint)
    # new total cost is calculated and printed to the user
    roomCost = totalCost(paintCost, length, height, width, windows, doors)
    # individual room costs
    print("Room " + str(roomNum) + "'s cost will be " + str(roomCost))
    # all room costs added together
    allCost = allCost + roomCost
    # counter increased
    counter += 1
    roomNum += 1
    # variable rounded
    allCost = round(allCost, 2)
# price printed for user to view
print("The price of painting" + str(rooms) + " room(s) will be $" + str(allCost))
