public class Art
{

        public static void main(String [] args)
        {
                System.out.println(" \t .");
                System.out.println("\t,O,");
                System.out.println("       ,OOO,");
                System.out.println(" \'oooooOOOOOooooo\'");
                System.out.println("   `OOOOOOOOOOO`");
                System.out.println("     `OOOOOOOO`");
                System.out.println("     oOOO\'I\'OOOo");
                System.out.println("    oOO\'  I  \'OOo");
                System.out.println("   o\'     I     \'o");
                System.out.println("\t  I");
                System.out.println("\t  I");
                System.out.println("\t  I");
        }
}