print("Welcome to the Akinator Chatbot, where you're guaranteed to lose.")
name = input("So, what's your name user?: ")
print("Nice to meet you " + name + "! Will you outsmart me?")

replay = 1

while replay == 1:
   print("\nHere are some ice cream flavours to choose from: \n\n"
         "1. Default (Vanilla)\n"
         "2. Chocolate\n"
         "3. Strawberry\n"
         "4. Sandwich (Cookies and Cream)\n"
         "5. Tooth Paste (Mint)\n"
         "6. Raisin Bran (Pecan)\n"
         "7. Napoleon Bonaparte (Neapolitan) {If you've ever tried them all together you know this is a whole new flavor}\n"
         "8. Addiction (Coffee)\n"
         "9. Fruity (Mango)\n"
         "10. Basic (Milk)\n")

   print("\nRemember to answer yes or no only, because I can't decipher your questions. Save that for Google.")

   question = input(
       "\nAnyhow, is this flavor made out of nuts/beans (Yes chocolate and vanilla count; so does Neapolitan): ")
   question = question.upper()
   if question == "YES":
       question = input("\nIs this flavor of ice cream brown in color (Pecan doesn't count): ")
       question = question.upper()
       if question == "YES":
           question = input("\nIs this flavor a combination flavour: ")
           question = question.upper()
           if question == "YES":
               print("You're probably planning to rule France because your chosen flavor was Neapolitan (Napoleon)!")
           if question == "NO":
               question = input("\nDoes this flavor have anything to do with waking someone up: ")
               question = question.upper()
               if question == "YES":
                   print("You must be a high school student because your chosen flavor was Coffee (Addiction)!")
               if question == "NO":
                   print("You're like the other girls because your chosen flavor was Chocolate!")
       if question == "NO":
           question = input("\nDoes this ice cream have nuts in it: ")
           question = question.upper()
           if question == "YES":
               print("You must be a Southerner because your chosen flavor was Pecan (Raisin Bran)!")
           if question == "NO":
               print("Ye-haw you must be a cowboy because your chosen flavor was Vanilla!")
   elif question == "NO":
       question = input("\nDoes this flavor have anything to do with plants: ")
       question = question.upper()
       if question == "YES":
           question = input("\nDoes this flavor have anything to do with fruit: ")
           question = question.upper()
           if question == "YES":
               question = input("\nDoes this flavor usually grow in Florida or California: ")
               question = question.upper()
               if question == "YES":
                   print("How's it like to be a fruit fanatic because your chosen flavor was Strawberry!")
               if question == "NO":
                   print("You are probably South Asian because your chosen flavor was Mango (Fruity)!")
           if question == "NO":
               print("You must love brushing your teeth because your chosen flavor was Mint (Toothpaste).")
       if question == "NO":
           question = input("\nDoes this flavor have cookies crushed into it: ")
           question = question.upper()
           if question == "YES":
               print("You're a cookie monster fan because your chosen flavor was Cookies and Cream!")
           if question == "NO":
               print("You're quite simplistic because your chosen flavor was Milk (Basic)")
   else:
       print("\nQuite a devious response of you. However loops don't work with me so start again.")
   correct = int(input("\nWas I correct:\n"
                       "Answer with a number\n\n"
                       "1. Yes\n"
                       "2. No\n"))
   if correct == 1:
       print("I told you I would win! (This wasn't rigged, trust me)")
   elif correct == 2:
       print("What? How? No way, we have to try this again!")
   else:
       print("Uh oh looks like you'll have to restart (: ")
   replay = int(input("\nAnswer with a number:\n\n"
                      "1. Yes\n"
                      "2. No\n"
                      "Answer here: "))
   if replay == 1:
       continue
   if replay == 2:
       print("Bye User, trying beating my system next time.")
       replay = 0