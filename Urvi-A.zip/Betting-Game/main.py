# Author: Urvi Akhouri
# Program Name: Betting Game
# Description: The purpose of this project is to create a betting game
# Date: 01/10/23
# Version: 1.0

import random

balance = 1000

while balance > 0:
    answer = random.randint(1, 2)
    maxBet = 1000
    if balance <= 1000:
        maxBet = balance
    bet = int(input("Enter an amount to bet between 5 and your total balance: "))
    if 5 <= bet <= maxBet:
        guess = int(input("Enter your guess (1 or 2):"))
        if guess == answer:
            balance = balance + bet
        else:
            balance = balance - bet
        print(balance)
    else:
        print("invalid bet message")
    if balance >= 5:
        choice = input("Would you like to continue: ")
        choice = choice.upper()
        if choice == "NO":
            break
    else:
        break

print("I hope you enjoyed this game User. You balance was " + str(balance))