# Author: Urvi Akhouri
# Program Name: Boxing Simulator
# Description: The purpose of this project is to simulate playing as a boxer
# Date: 01/12/23
# Version: 1.0

import random

replay = 1
while replay == 1:
    userHP = 100
    compHP = 100
    while userHP > 0 and compHP > 0:
        print(userHP)
        print(compHP)
        print("How would you like to attack?\n"
              "1. Block\n"
              "2. Jab\n"
              "3. Hook\n"
              "4. Uppercut\n"
              "5. Straight\n")
        choice = int(input("Enter how you would like to attack (Numbers Only): "))
        compChoice = random.randint(1, 5)
        userDamage = 0
        userDefense = 0
        compDamage = 0
        compDefense = 0
        if choice == 1:
            userDamage = 0
            userDefence = random.randint(5, 10)
        elif choice == 2:
            userDamage = random.randint(1, 5)
            userDefence = random.randint(3, 5)
        elif choice == 3:
            userDamage = random.randint(3, 7)
            userDefence = random.randint(1, 3)
        elif choice == 4:
            userDamage = random.randint(4, 8)
            userDefence = random.randint(0, 2)
        elif choice == 5:
            userDamage = random.randint(2, 6)
            userDefence = random.randint(2, 4)
        else:
            print("You dropped your hands.")
        if compChoice == 1:
            compDamage = 0
            userDefence = random.randint(5, 10)
        if compChoice == 2:
            compDamage = random.randint(1, 5)
            userDefence = random.randint(3, 5)
        if compChoice == 3:
            compDamage = random.randint(3, 7)
            userDefence = random.randint(1, 3)
        if compChoice == 4:
            compDamage = random.randint(4, 8)
            userDefence = random.randint(0, 2)
        if compChoice == 5:
            compDamage = random.randint(2, 6)
            userDefence = random.randint(2, 4)
        userChange = compDamage - userDefense
        compChange = userDamage - compDefense
        if userChange > 0:
            userHP = userHP - userChange
        if compChange > 0:
            compHP = compHP - compChange
        if compHP <= 0:
            print("You Win!")
        if userHP <= 0:
            print("You Lose.")
    replay = int(input("Would you like to play again?\n"
                       "1. Yes\n"
                       "2. No\n"
                       "Enter your response (Numbers Only): "))
