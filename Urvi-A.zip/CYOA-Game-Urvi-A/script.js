/* VARIABLES */
let enterButton;
let choiceButton1;
let choiceButton2;
let screen = 0;

/* SETUP RUNS ONCE */
function setup() {
  createCanvas(600, 400);
  textAlign(CENTER);
  textSize(20);
  noStroke();
  showHomeScreen();
}

function showHomeScreen() {
  background("pink");
  text("Welcome to Misinformation, the Dating Sim!", width / 2, height / 2 - 100);
  text("Press Enter to Start", width / 2, height / 2);

  enterButton = createButton("Enter");
  enterButton.position(width / 2 - 50, height / 2 + 50);
  enterButton.size(100, 50);
  enterButton.style('background-color', 'plum');
  enterButton.style('color', 'black');
  enterButton.mousePressed(() => {
    enterButton.remove(); // Remove the button from the canvas
    screen = 1;
    showFirstDecisionScreen();
  });
}

function showFirstDecisionScreen() {
  background("paleturquoise");
  text("You meet someone too good to be true. What do you do?", width / 2, height / 2 - 100);

  choiceButton1 = createButton("Go for\nthem");
  choiceButton1.position(width / 2 - 150, height / 2 + 50);
  choiceButton1.size(100, 50);
  choiceButton1.style('background-color', 'plum');
  choiceButton1.style('color', 'black');
  choiceButton1.mousePressed(() => {
    if (choiceButton1) {
      choiceButton1.remove();
    }
    if (choiceButton2) {
      choiceButton2.remove();
    }
    screen = 2;
    showFirstEnding();
  });

  choiceButton2 = createButton("Stay wary\nof them");
  choiceButton2.position(width / 2 + 50, height / 2 + 50);
  choiceButton2.size(100, 50);
  choiceButton2.style('background-color', 'plum');
  choiceButton2.style('color', 'black');
  choiceButton2.mousePressed(() => {
    if (choiceButton1) {
      choiceButton1.remove();
    }
    if (choiceButton2) {
      choiceButton2.remove();
    }
    screen = 3;
    showSecondEnding();
  });
}

function showFirstEnding() {
  background("lightgreen");
  text("They weren't real. You got catfished.", width / 2, height / 2 - 100);
}

function showSecondEnding() {
  background("lightcoral");
  text("You decided to stay wary and avoided a disaster!", width / 2, height / 2 - 100);
}