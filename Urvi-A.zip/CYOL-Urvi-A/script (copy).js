/* VARIABLES */
let hope = 0;
let despair = 0;
let interestN;
let interestJ;
let forest;
let forest2;
let school;
let showChoices = true; 
let currentBackground = 'forest';
let showStartScreen = true;
let advanceStory = false;

/* PRELOAD LOADS FILES */
function preload() {
  interestN = loadImage("assets/nagito.png"); 
  interestJ = loadImage("assets/junko.png"); 
  forest = loadImage("assets/creepyForest.jpeg");
  school = loadImage("assets/school.jpeg");
  forest2 = loadImage("assets/forest2.jpeg");
}

/* SETUP RUNS ONCE */
function setup() {
  createCanvas(500, 500);
  background(forest);
}

/* DRAW LOOP REPEATS */
function draw() {
  if (showStartScreen) {
    drawStartScreen();
  } else {
    textSize(12);
    if (currentBackground === 'forest') {
      placeO();
    } else if (currentBackground === 'forest2') {
      placeT();
    } else if (currentBackground === 'school') {
      placeS();
    }
  }
}

function drawStartScreen() {
  background(153, 51, 102); 
  fill(0); 
  textAlign(CENTER, CENTER);
  textSize(32);
  text("Hope Or Despair: A Dating Sim", width / 2, height / 3);
  textSize(18);
  text("Click to Start", width / 2, height / 2);
}

function placeO() {
  background(forest); 

  image(interestN, 300, 260);
  image(interestJ, 0, 260, 400, 240);

  fill(255, 255, 255);
  if (showChoices) {
    strokeWeight(1);
    text("You awake? How did you get here?", 150, 50, 200);
    drawChoiceBoxes();
  }
}

function placeT() {
  background(forest2);

  image(interestN, 300, 200, 100, 200);
  image(interestJ, 0, 200, 100, 200);

  fill(255, 255, 255);
  if (advanceStory) {
    text("Should we move to a safer place?", 150, 50, 200);
    drawForest2Choices();
  }
  if (despair >= 1 && !advanceStory) {
    text("Who cares? Bye.", 150, 250, 200);
    currentBackground = 'school';
    advanceStory = true;
  } 
  if (hope >= 1 && !advanceStory) {
    text("Ah, let's get you back", 350, 250, 200);
    currentBackground = 'school';
    advanceStory = true;
  }
}

function placeS() {
  background(school);

  image(interestN, 300, 260);
  image(interestJ, 0, 260, 400, 240);

  fill(255, 255, 255);
  if (advanceStory) {
    text("Welcome to the school. What should we do now?", 150, 50, 200);
    drawSchoolChoices();
  }
}

/* FUNCTIONS */
function drawChoiceBoxes() {
  // Box 1
  fill(200, 50, 50);
  rect(100, 100, 125, 50);
  fill(255);
  textAlign(CENTER, CENTER);
  text("I ran from my problems", 162.5, 125);

  // Box 2
  fill(50, 50, 200);
  rect(300, 100, 125, 50);
  fill(255);
  textAlign(CENTER, CENTER);
  text("I needed to calm down", 362.5, 125);
}

function drawForest2Choices() {
  // Box 1
  fill(200, 50, 50);
  rect(100, 100, 125, 50);
  fill(255);
  textAlign(CENTER, CENTER);
  text("Let's stay here", 162.5, 125);

  // Box 2
  fill(50, 50, 200);
  rect(300, 100, 125, 50);
  fill(255);
  textAlign(CENTER, CENTER);
  text("Let's find the school", 362.5, 125);
}

function drawSchoolChoices() {
  // Box 1
  fill(200, 50, 50);
  rect(100, 100, 125, 50);
  fill(255);
  textAlign(CENTER, CENTER);
  text("Explore the school", 162.5, 125);

  // Box 2
  fill(50, 50, 200);
  rect(300, 100, 125, 50);
  fill(255);
  textAlign(CENTER, CENTER);
  text("Talk to someone", 362.5, 125);
}

function mousePressed() {
  if (showStartScreen) {
    showStartScreen = false;
  } else {
    if (showChoices && currentBackground === 'forest') {
      if (mouseX > 100 && mouseX < 225 && mouseY > 100 && mouseY < 150) {
        // Choice 1
        despair++;
        console.log("Despair increased: " + despair);
        showChoices = false;
        currentBackground = 'forest2';
      } else if (mouseX > 300 && mouseX < 425 && mouseY > 100 && mouseY < 150) {
        // Choice 2
        hope++;
        console.log("Hope increased: " + hope);
        showChoices = false;
        currentBackground = 'forest2';
      }
    } else if (currentBackground === 'forest2' && advanceStory) {
      if (mouseX > 100 && mouseX < 225 && mouseY > 100 && mouseY < 150) {
        // Choice 1 in forest2
        console.log("Staying in the forest");
        advanceStory = false;
      } else if (mouseX > 300 && mouseX < 425 && mouseY > 100 && mouseY < 150) {
        // Choice 2 in forest2
        console.log("Moving to school");
        currentBackground = 'school';
        advanceStory = true;
      }
    } else if (currentBackground === 'school' && advanceStory) {
      if (mouseX > 100 && mouseX < 225 && mouseY > 100 && mouseY < 150) {
        // Choice 1 in school
        console.log("Exploring the school");
        // Additional story code can go here
      } else if (mouseX > 300 && mouseX < 425 && mouseY > 100 && mouseY < 150) {
        // Choice 2 in school
        console.log("Talking to someone");
        // Additional story code can go here
      }
    }
  }
}