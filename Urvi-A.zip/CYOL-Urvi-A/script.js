/* VARIABLES */
let hope = 0;
let despair = 0;
let interestN;
let interestJ;
let forest;
let forest2;
let school;
let showChoices = true; 
let currentBackground = 'forest';
let showForest2Choices = false;
let showStartScreen = true; 

/* PRELOAD LOADS FILES */
function preload(){
  interestN = loadImage("assets/nagito.png"); 
  interestJ = loadImage("assets/junko.png"); 
  forest = loadImage("assets/creepyForest.jpeg");
  school = loadImage("assets/school.jpeg");
  forest2 = loadImage("assets/forest2.jpeg");
}

/* SETUP RUNS ONCE */
function setup() {
  createCanvas(500,500);
  background(forest);
}

/* DRAW LOOP REPEATS */
function draw() {
  if (showStartScreen) {
    drawStartScreen();
  } else {
    textSize(12);
    placeO();
    placeT();
  }
}

function drawStartScreen() {
  background(153, 51, 102); 
  fill(0); 
  textAlign(CENTER, CENTER);
  textSize(32);
  text("Hope Or Despair", width / 2, height / 3);
  textSize(18);
  text("Click to Start", width / 2, height / 2);
}

function placeO() {
  if (currentBackground === 'forest') {
    background(forest); 

    image(interestN, 300, 260);
    image(interestJ, 0, 260, 400, 240);

    if (showChoices) {
      fill(255, 255, 255);
      strokeWeight(50);
      text("You awake? How did you get here?", 350, 250, 100);
      drawChoiceBoxes();
    }
  }
}

function placeT() {
  if (currentBackground === 'forest2') {
    background(forest2);

    image(interestN, 300, 260);
    image(interestJ, 0, 260, 400, 240);

    fill(255, 255, 255);
    if (despair == 1) {
      text("Who cares? Bye.", 150, 250, 100);
    } 
    if (hope == 1) {
      text("Ah, let's get you back", 350, 250, 100);
    }
  }
}

/* FUNCTIONS */
function drawChoiceBoxes() {
  // Box 1
  fill(200, 50, 50);
  rect(100, 100, 100, 50);
  fill(255);
  textAlign(CENTER, CENTER);
  text("I ran from my problems", 150, 125);

  // Box 2
  fill(50, 50, 200);
  rect(300, 100, 100, 50);
  fill(255);
  textAlign(CENTER, CENTER);
  text("I needed to calm down", 350, 125);
}

function mousePressed() {
  if (showStartScreen) {
    showStartScreen = false;
  } else {
    if (showChoices) {
      if (mouseX > 100 && mouseX < 200 && mouseY > 100 && mouseY < 450) {
        despair++;
        console.log("Despair increased: " + despair);
        showChoices = false;
        text("Who cares? Bye.", 150, 250, 100);
      }

      if (mouseX > 300 && mouseX < 400 && mouseY > 100 && mouseY < 450) {
        hope++;
        console.log("Hope increased: " + hope);
        showChoices = false;
        fill(0, 0, 0);
        text("Ah, let's get you back", 350, 250, 100);
      }
      currentBackground = 'forest2';
    }
  }
}