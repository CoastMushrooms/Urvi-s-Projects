# functions to determine cost and car type
def carCost(beforeCost, years, moneyDown):
    preCost = beforeCost - moneyDown
    costCar = (preCost + (preCost * 0.035))
    months = years * 12
    monthCost = costCar/months
    if monthCost > 999:
        print("The monthly cost for this car will be: {:,.2f}".format(monthCost))
    else:
        print("The monthly cost for this car will be: {:.2f}".format(monthCost))


def carCharacter(carNum, carYear, carMake, carModel, carColor, carMiles, carCost):
    print("\nCar Number: {}".format(carNum))
    print("Year: {}".format(carYear))
    print("Maker: {}".format(carMake))
    print("Model: {}".format(carModel))
    print("Color: {}".format(carColor))
    print("MPG: {}".format(carMiles))
    print("Cost: ${}".format(carCost))