# Author: Urvi Akhouri
# Program Name: Car Pricing
# Description: The purpose of this project is to be a dealership
# Date: 04/18/23
# Version: 1.0

# variables imported
from car import carCost
from car import carCharacter

# cars displayed
carCharacter(1, 2015, "Toyota", "Prius", "Dark Blue", 50, 27000)
carCharacter(2, 2018, "Honda", "Accord", "Black", 30, 23000)
carCharacter(3, 2023, "KIA", "Sportage", "Silver", 40, 24500)

# info for cars and cost reduction
carInfo = int(input("\nEnter which car you would like to purchase: "))
moneyDown = int(input("How much money would you like to put down towards your payment: "))
years = int(input("How many years do you need to pay this off: "))

#if/elif/else change for car purchase
if carInfo == 1:
    carCost(27000, years, moneyDown)
elif carInfo == 2:
    carCost(23000, years, moneyDown)
elif carInfo == 3:
    carCost(24500, years, moneyDown)
else:
    print("Get Out.")