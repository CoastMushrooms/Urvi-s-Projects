# Author: Urvi Akhouri
# Program Name: Poker
# Description: The purpose of this project is replicate cards
# Date: 04/27/23
# Version: 1.0

import random

# Initialize tuples for ranks and suits
ranks = ("2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace")
suits = ("Spades", "Clubs", "Diamonds", "Hearts")

# Print all 52 cards in the deck
for rank in ranks:
    for suit in suits:
        print(rank + " of " + suit)
    print("------------")

# Print a random card
random_rank_index = random.randint(0, len(ranks)-1)
random_suit_index = random.randint(0, len(suits)-1)
random_card = ranks[random_rank_index] + " of " + suits[random_suit_index]
print("Your random card is: " + random_card)