public class Chess
{
  String [][] board;
  int queenRow;
  int queenCol;
  String [] pieces = {"[A]", "[B]", "[C]", "[D]"};
  
  public Chess()
  {
    board = new String[8][8];
    
    fill();
    
    display();
    
    for(int i = 0; i < pieces.length; i++)
    {
      find(pieces[i]);
    }
  }
  
  public void display()
  {
    for(int row = 0; row < board.length; row++)
    {
      for(int col = 0; col < board.length; col++)
      {
        System.out.print(board[row][col]);
      }
      System.out.println();
    }
  }
  
  public void fill()
  {
    for(int row = 0; row < board.length; row++)
    {
      for(int col = 0; col < board.length; col++)
      {
      board[row][col] = "[ ]";
      }
    }
    
    queenRow = (int)(Math.random()*8);
    queenCol = (int)(Math.random()*8);
    board[queenRow][queenCol] = "[Q]";
    
    for(int i = 0; i < pieces.length; i++)
    {
      int ranRow = (int)(Math.random()*8);
      int ranCol = (int)(Math.random()*8);
    
      while(board[ranRow][ranCol] != "[ ]")
      {
        ranRow = (int)(Math.random()*8);
        ranCol = (int)(Math.random()*8);
      }
      board[ranRow][ranCol] = pieces[i];
    }
  }
  
  public void find(String piece)
  {
    int pieceRow = -1;
    int pieceCol = -1;
    
    for(int row = 0; row < board.length; row++)
    {
      for(int col = 0; col < board[0].length; col++)
      {
        if(board[row][col].equals(piece))
        {
          pieceRow = row;
          pieceCol = col;
        }
      }
    }
    
    if(pieceRow != -1)
    {
      if(queenRow == pieceRow)
      {
        System.out.println("Queen can attack " + piece + " by ROW!");
      }
    
      else if(queenCol == pieceCol)
      {
        System.out.println("Queen can attack " + piece + " by COLUMN!");
      }
    
      else if(Math.abs(queenRow-pieceRow) == Math.abs(queenCol-pieceCol))
      {
        System.out.println("Queen can attack " + piece + " by DIAGONAL!");
      }
      else
      {
        System.out.println("Queen CAN'T attack " + piece);
      }
    }
  }
  
  public static void main(String [] args)
  {
    Chess run = new Chess();
  }
}