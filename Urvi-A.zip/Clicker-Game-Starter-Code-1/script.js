/* VARIABLES */
let score = 0;

/* SETUP RUNS ONCE */
function setup() {
	createCanvas(400, 400);
  background(137, 213, 210);
  
  //Create game sprite
  target = new Sprite(100, 100, 50);
  target.color = color(56, 34, 98);
  //Set speed of target change
  target.x = 200;
  target.y = 200;
}

/* DRAW LOOP REPEATS */
function draw() {
  background(137, 213, 210);

  //Draw the score
  fill(0, 128, 128);
  textAlign(LEFT);
  textSize(20);
  text('Score = ' + score, 10, 30);

  //Increase score when player clicks target
  if (target.mouse.presses()) {
    score = score + 1;
    moveTarget();
  }

/* FUNCTIONS */
function moveTarget() {
  //Move target to random locations
    target.x = random(25, 375);
    target.y = random(25, 375);
  }
}