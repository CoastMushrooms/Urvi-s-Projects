/* VARIABLES */
let score = 0;

/* SETUP RUNS ONCE */
function setup() {
	createCanvas(400, 400);
  background(137, 213, 210);
  
  //Create game sprite


  //Set speed of target change

}

/* DRAW LOOP REPEATS */
function draw() {
  background(137, 213, 210);

  //Draw the score
  fill(0, 128, 128);
  textAlign(LEFT);
  textSize(20);
  text('Score = ' + score, 10, 30);

  //Increase score when player clicks target
  //if (target.mouse.presses()) {

  //}
  
}

/* FUNCTIONS */
function moveTarget() {
  //Move target to random locations
  //target.x = 
  //target.y = 

}