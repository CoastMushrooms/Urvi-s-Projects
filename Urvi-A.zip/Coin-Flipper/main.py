#Author: Urvi Akhouri
#Program Name: Coin Flipper
#Description: The purpose of this project is to create a coin flipping simulation
#Date: 12/07/22
#Version: 1.0

import random

numFlips = int(input("Enter the number of times to flip the coin: "))
numHeads = 0

for x in range(numFlips):
    flip = random.randrange(1, 2)
    if flip == 1:
        numHeads = numHeads + 1

numTails = numFlips - numHeads

print(numHeads)
print(numTails)