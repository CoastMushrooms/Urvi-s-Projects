# Author: Urvi Akhouri
# Program Name: Dataset Average
# Description: The purpose of this project is to find average
# Date: 04/26/23
# Version: 1.0

# variables
suM = 0
dataset = (1, 3, 5, 7, 9)

# length
size = len(dataset)

# sum of numbers
for i in range(size):
    suM += dataset[i]

# average calculated
average = suM / float(size)

# dataset and average
print("Dataset:", dataset)
print("Average:", average)