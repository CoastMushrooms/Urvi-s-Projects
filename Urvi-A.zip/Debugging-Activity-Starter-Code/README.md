Test out your debugging skills!

Directions:
- Fork this project.
- Run this program. What error(s) do you see?
- Fix the errors. Remember: there are multiple!
