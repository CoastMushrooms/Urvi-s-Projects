import random

trex = {
    "Name": "T-Rex",
    "Health": 20,
    "Aggressive Damage": random.randint(6, 10),
    "Defensive Damage": random.randint(4, 8),
    "Aggressive Defense": random.randint(0, 2),
    "Defensive Defense": random.randint(3, 5)
}

stego = {
    "Name": "Stegosaurus",
    "Health": 40,
    "Aggressive Damage": random.randint(3, 6),
    "Defensive Damage": random.randint(1, 4),
    "Aggressive Defense": random.randint(1, 3),
    "Defensive Defense": random.randint(4, 8)
}

tricer = {
    "Name": "Triceratops",
    "Health": 30,
    "Aggressive Damage": random.randint(4, 8),
    "Defensive Damage": random.randint(2, 6),
    "Aggressive Defense": random.randint(1, 4),
    "Defensive Defense": random.randint(2, 6)
}