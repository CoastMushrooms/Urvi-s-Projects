# Author: Urvi Akhouri
# Program Name: Dinosaur Battle
# Description: The purpose of this project is to battle
# Date: 05/10/23
# Version: 1.0

from dinosaur import trex, stego, tricer
import random


def dinoStats(dino):
    print("Name: {}\n"
          "Health: {}\n"
          "Aggressive Damage: {}\n"
          "Defensive Damage: {}\n"
          "Aggressive Defense: {}\n"
          "Defensive Defense: {}\n".format(dino['Name'], dino['Health'], dino['Aggressive Damage'], dino['Defensive Damage'], dino['Aggressive Defense'], dino['Defensive Defense']))


def battle(attacker, defender, attack_type):
    if attack_type == "1":
        damage = attacker["Aggressive Damage"]
        defense = defender["Aggressive Defense"]
    else:  # Defensive attack
        damage = attacker["Defensive Damage"]
        defense = defender["Defensive Defense"]

    if damage > defense:
        return damage - defense
    else:
        return 0


def winner(dinoU, dinoC):
    if dinoU["Health"] <= 0 and dinoC["Health"] <= 0:
        print("It's a tie! Both dinosaurs knocked each other out.")
    elif dinoU["Health"] <= 0:
        print("The winner is {}!".format(dinoC['Name']))
    else:
        print("The winner is {}!".format(dinoU['Name']))


print("Dinosaur Stats:\n" +
      str(dinoStats(trex)) + "\n\n" +
      str(dinoStats(stego)) + "\n\n" +
      str(dinoStats(tricer)) + "\n")

userChoice = int(input("Choose a dinosaur:\n"
                       "1. T-Rex\n"
                       "2. Stegosaurus\n"
                       "3. Triceratops\n\n"
                       "Enter a number: "))

computerChoice = random.randint(1, 3)

if userChoice == 1:
    dinoU = trex
elif userChoice == 2:
    dinoU = stego
elif userChoice == 3:
    dinoU = tricer

if computerChoice == 1:
    dinoC = trex
elif computerChoice == 2:
    dinoC = stego
elif computerChoice == 3:
    dinoC = tricer

userTurn = False
computerTurn = False

turn = random.randint(1, 2)
if turn == 1:
    userTurn = True
else:
    computerTurn = True

while dinoU["Health"] > 0 and dinoC["Health"] > 0:
    print("{}'s Health: {} points\n"
          "{}'s Health: {} points\n".format(dinoU['Name'], dinoU['Health'], dinoC['Name'], dinoC['Health']))

    if userTurn:
        print("Your turn!")
        userChoice = input("Choose your move Aggressive (1) / Defensive (2): ")
        computerChoice = random.choice(['Aggressive', 'Defensive'])

        userDamage = battle(dinoU, dinoC, userChoice)
        computerDamage = battle(dinoC, dinoU, computerChoice)

        dinoC['Health'] -= userDamage
        dinoU['Health'] -= computerDamage

        userTurn = False
        computerTurn = True
    else:
        print("Computer's turn!")
        userChoice = random.choice(['Aggressive', 'Defensive'])
        computerChoice = input("Choose computer's move Aggressive (1) / Defensive (2): ")

        userDamage = battle(dinoU, dinoC, userChoice)
        computerDamage = battle(dinoC, dinoU, computerChoice)

        dinoC['Health'] -= userDamage
        dinoU['Health'] -= computerDamage

        userTurn = True
        computerTurn = False

if dinoU['Health'] <= 0 and dinoC['Health'] <= 0:
    print("{}'s Health: {} points".format(dinoU['Name'], dinoU['Health']))
    print("{}'s Health: {} points".format(dinoC['Name'], dinoC['Health']))
else:
    print("{}'s Health: {} points".format(dinoU['Name'], dinoU['Health']))
    print("{}'s Health: {} points".format(dinoC['Name'], dinoC['Health']))

winner(dinoU, dinoC)