# lists
firstName = ("Thomas", "Eugene", "Roxanne", "Sophia", "Quinn")
lastName = ("Katz", "Hart", "Starson", "Althea", "Kentala")
jobs = ("Assistant", "VP of Marketing", "VP of Sales", "Intern", "VP of Production")
hourlyWages = (22, 32, 32, 15, 32)