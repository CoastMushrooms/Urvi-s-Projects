# Author: Urvi Akhouri
# Program Name: Employer Hub
# Description: The purpose of this project is to manage employees
# Date: 05/04/23
# Version: 1.0

# imported lists
from employees import firstName
from employees import lastName
from employees import jobs
from employees import hourlyWages

# list
hoursWorked = []
totalWages = []

# counters
counter = 0
counter2 = 0
counter4 = 0

# variable
allCost = 0

# for loops
for x in firstName:
    # hours entered
    hours = int(input("Enter hours worked for " + str(firstName[counter]) + " " + str(lastName[counter]) + ": "))
    counter += 1
    hoursWorked.append(hours)
for x in hoursWorked:
    # wage calculated
    money = hoursWorked[counter2] * hourlyWages[counter2]
    counter2 += 1
    totalWages.append(money)
for x in totalWages:
    # total wages
    allCost = sum(totalWages)
for x in jobs:
    # employees information printed
    print("Employee Name: {} {} | Position: {} | Total Wages Paid: {:,.2f} | Hours Worked: {}".format(firstName[counter4], lastName[counter4], jobs[counter4], totalWages[counter4], hoursWorked[counter4]))
    counter4 += 1
# total wages
print("Total Wages Paid: {:,.2f}".format(allCost))
