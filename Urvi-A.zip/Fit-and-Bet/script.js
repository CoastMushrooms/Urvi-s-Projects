function generateRandomAmount() {
  return Math.floor(Math.random() * 1000) + 1; // Generate a random amount between 1 and 1000 dollars
}

function generateRandomCharity() {
  const charities = ["Charity A", "Charity B", "Charity C", "Charity D", "Charity E"];
  const randomCharity = charities[Math.floor(Math.random() * charities.length)];
  return randomCharity;
}

const randomAmount = generateRandomAmount();
const randomCharity = generateRandomCharity();
console.log(`Donate $${randomAmount} to ${randomCharity}`);



function generateRandomAmount() {
  return Math.floor(Math.random() * 500) + 1;
}

function generateRandomCharity() {
  const charities = ["Wildlife Conservation Society", "Helen Keller Foundation", "National Federation of the Blind", "CancerCare", "Unbound", "Center for Community Change Action", "Freedom From Religion Foundation", "Government Accountability Project (GAP)"];
  const randomCharity = charities[Math.floor(Math.random() * charities.length)];
  return randomCharity;
}
// Function to handle the click event of the Generate button
document.getElementById("generateButton").addEventListener("click", function() {
  const randomAmount = generateRandomAmount();
  const randomCharity = generateRandomCharity();
  const resultParagraph = document.getElementById("result");
  resultParagraph.textContent = `Donate $${randomAmount} to ${randomCharity}`;
});