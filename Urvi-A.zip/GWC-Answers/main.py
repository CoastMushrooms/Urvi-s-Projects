#1. Write a program which takes in a user's age and if age<18, it tells them that they do not meet the age requirements for the job and are inelligeble to apply. However,if age>18, the program then asks how many years of work experience they have. If work experience is < 2, then the program tells them that they have too little experince for this job and are inlelligible to apply. However, if work experience is >2, the program tells them they meet the application requirements and can proceed with the application. 

age = int(input("What is your age: "))

if age < 18:
  print("You're underage bruh. No job for you.")
elif age >= 18:
  job = int(input("How many years of work experience do you have: "))
  if job < 2:
    print("You're too inexperienced. Get some experience elsewhere.")
  else:
    print("You may procced with the application for the job.")
else:
  print("What? How?")

# 2. Write a program which asks the user how many items were ordered and how many items are in stock. Then, print out a statement which tells the user how many items were ordered and how many are in stock. If the number of items in stock is less than the number of items ordered, tell the user to resupply the inventory. Else, set the package count  to the number of items ordered divided by 8 (each package can hold 8 items). If package count>1, tell the user that multiple packages are needed to fullfill this order. 

items = int(input("How many items were ordered: "))
left = int(input("How many items are left: "))

print(str(items) + " items were ordered")
print(str(left) + " items are left in stock")

if left < items:
  print("Restock everything")
else:
  packageCount = items/8
  if packageCount > 1:
    print("More than 1 box is needed")
  else:
    print(" ")
#3. Write a program which uses a while True loop to ask a user a trivia question of your choice. Within the while loop, keep track of the number of guesses the user makes. Up until guess number 3, each time the user makes an incorrect guess, give them a new hint (using if statements). After the 3rd guess, let the user continue to guess until they get the answer right and then print "Correct!"


# 4. Write a program which asks the user to input the dimensions of a grid and then print the grid using a nested for loop.

# 5. Write a program which prints out a number pattern as such: 
# 1 2 3 4 5
# 1 2 3 4 5
# 1 2 3 4 5
# 1 2 3 4 5
# 1 2 3 4 5

# 6. Write a program which prints out a number pattern as such: 
# 1 2 3 4 5
# 2 3 4 5 6
# 3 4 5 6 7
# 4 5 6 7 8
# 5 6 7 8 9

# 7. Write a program which prints out a number pattern as such: 
# 1 
# 1 2
# 1 2 3
# 1 2 3 4
# 1 2 3 4 5

# 8. Write a program which prints out the multiplication table up until 11 x 11 (row 1 has the 1 times table up until 1 x 11, row 2 has the 2 times table up until 2 x 11 and so on)

# 9. Write a program which counts the days of the week for 4 weeks using a nested for loop.
#Ex. Week: 1
#    Day: 1
#    Day: 2
#    Day: 3
#    Day: 4
#    Day: 5
#    Day: 6
#    Day: 7
# complete this pattern until week 4