# Welcome to Python Starter Code

This is the starter code for the Welcome to Python activity set. You can fork this program, then modify it. Feel free to tinker and play! We're just getting started on this journey!

### What is this file?
README.md file give you more documentation and information about a program. They are super helpful for describing what a program should do, any issues you've encountered, changes you want to make, and more. 

At GWC, we will include the following components in our README files:
- *Project requirements*. Features you should have when you complete your program.
- *Extensions*. Optional prompts you can use to extend your learning after you complete the base project.
- *Image Attributions*. If you used any images, include the link to where you found it and cite the author.
- *File Overview*. If there are multiple files, this section will give a quick description of each one and its purpose.

