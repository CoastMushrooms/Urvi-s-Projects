# Display 'hello' and 'GWC' in the console 
# sup there
print('hello')
print('GWC')
