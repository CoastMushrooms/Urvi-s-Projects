# Author: Urvi Akhouri
# Program Name: Groceries
# Description: The purpose of this is to choose groceries
# Date: 04/25/23
# Version: 1.0

# grocery list
groceries = ["Cheese", "Bread", "Milk", "Eggs"]

# counter
counter = 1

# while loop
while len(groceries) > 0:
    # loop and print
    for item in groceries:
        print(counter, item)
        counter += 1

    # reset
    counter = 1

    # user input and remove
    rem = int(input("Enter the number of the item you want to remove: "))
    if 0 < rem <= len(groceries):
        groceries.pop(rem - 1)
    else:
        print("Invalid input")

# list is empty
print("Grocery list is empty.")