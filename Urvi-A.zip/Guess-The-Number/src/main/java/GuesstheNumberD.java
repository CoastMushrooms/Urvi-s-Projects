import java.util.Scanner;

public class GuesstheNumberD
{
  Scanner keys = new Scanner(System.in);
  
  public GuesstheNumberD()
  {
    loops1();
  }
  
  public void loops1()
  {
    int a = (int)(Math.random()*100 + 1);
    int guess = 0;
    System.out.println("Your goal is to guess the number from 1 to 100");
    
    for(int i = 1; i <= 5; i ++)
    {
      System.out.println("Guess the number: ");
      guess = keys.nextInt();
      
      if(guess < a)
      {
        System.out.println("The number is higher than your guess.");
      }
      
      if(guess > a)
      {
        System.out.println("The number is lower than your guess.");
      }
      
      if(guess == a)
      {
        i = 11;
      }
    }
    
    if(guess != a)
    {
      System.out.println("The number is " + a);
      System.out.println("You Lost!");
      System.out.println("Better luck next time");
    }
    
    if(guess == a)
    {
      System.out.println("You Win!");
    }
  }
  
  public static void main(String [] args)
  {
    GuesstheNumberD run = new  GuesstheNumberD();
  }
}