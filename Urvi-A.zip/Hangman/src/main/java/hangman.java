import java.util.Scanner;
import java.io.*;

public class hangman
{
    Scanner keys = new Scanner (System.in);

    String hidden;
    String reveal = "";
    String guess = "";
    String guessed = "";
    String [] wordList = new String [26];

    boolean jOver = false;
    int guesses = 8;

    public hangman()
    {
        read();
        selectWord();

        while(!jOver)
        {
            display();
            comepareToHidden(guess());
            checkGame();
        }

        if(guesses > 0)
        {
            displayWin();
        }
        else
        {
            displayLoss();
        }
    }

    public void read()
    {
        File file = new File("words.txt");
        Scanner infile;

        try
        {
            infile = new Scanner(file);
            int index = 0;

            while(infile.hasNextLine())
            {
                String nextWord = infile.nextLine();
                if(nextWord.trim().length() != 0)
                {
                    wordList[index] = nextWord;
                    index++;
                }
            }
        }
        catch(FileNotFoundException e)
        {
            System.out.print("File not found");
        }
    }

    public void selectWord()
    {
        int fate = (int)(Math.random() * wordList.length);

        hidden = wordList[fate];

        for(int i = 0; i < hidden.length(); i++)
        {
            String letter = hidden.substring(i, i + 1);

            if(letter.equals("'") || letter.equals(".") || letter.equals(" ") || letter.equals("?") || letter.equals(",") || letter.equals("!"))
            {
                reveal += letter;
            }

            else
            {
                reveal += "-";
            }
        }
    }

    public void display()
    {
        //display the reveal String
        System.out.println("*******************");
        System.out.println(reveal);
    }

    public String guess()
    {
        int g = 0;
        String letter = "";

        while(g == 0)
        {
            System.out.print("Guess a letter: ");
            letter = keys.nextLine();

            for(int i = 0; i < guessed.length(); i++)
            {
                while(letter.length() > 1 || letter.equals(guessed.substring(i, i + 1)))
                {
                    if(letter.equals(guessed.substring(i, i + 1)))
                    {
                        System.out.println("You guessed that already");
                        letter = keys.nextLine();
                    }

                    if(letter.length() > 1)
                    {
                        System.out.print("Have you ever played Hangman. Enter one letter: ");
                        letter = keys.nextLine();
                    }
                }
            }
            g++;
        }
        guessed += letter;
        return letter;
    }

    public void checkGame()
    {
        if(reveal.equals(hidden))
        {
            guess += "Win";
            jOver = true;
            display();
        }

        if(guesses == 0)
        {
            jOver = true;
        }
    }

    public void displayWin()
    {
        System.out.println("Congrats! You guessed the hidden phrase");

        System.out.print("Press r to play again: ");
        String respo = keys.nextLine();

        if(respo.equalsIgnoreCase("r"))
        {
            new hangman();
        }
    }

    public void displayLoss()
    {
        System.out.println("Congrats, you're a loser.");

        System.out.print("Press r to play again: ");
        String respo = keys.nextLine();

        if(respo.equalsIgnoreCase("r"))
        {
            new hangman();
        }
    }

    public void comepareToHidden(String letter)
    {
        boolean valid = false;
        for(int i = 0; i < hidden.length(); i++)
        {
            String dork = hidden.substring(i, i + 1);

            if(letter.equalsIgnoreCase(dork))
            {
                valid = true;
                reveal = reveal.substring(0, i) + dork + reveal.substring(i + 1, reveal.length());
            }
        }
        if(!valid)
        {
            System.out.println("WRONG");
            guesses--;
            System.out.println("You have " + guesses + " guesses remaining.");
        }
    }

    public static void main(String [] args)
    {
        hangman run = new hangman();
    }
}