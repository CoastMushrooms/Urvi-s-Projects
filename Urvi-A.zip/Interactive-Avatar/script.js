/* VARIABLES */

/* SETUP RUNS ONCE */
function setup() {
  //sets the screen size
  createCanvas(400,400); 

  //sets the background color
  background(255,249,226); 
}

/* DRAW LOOP REPEATS */
function draw() {
  angleMode(DEGREES);
  rectMode(CENTER);

  x = 170
  y = 230
  t = 200
  w = 50
  h = 40
  
  //Face
  fill(209, 120, 81);
  ellipse(t, t, 175, t);

  //Eyes
  if(mouseIsPressed) {
    //Eyes Closed
    fill(0, 0, 0);
    ellipse(x, x, w, h/8);
    ellipse(y, x, w, h/8);

    fill(209, 120, 81);
    arc(t, y, 50, 50, 0, 180);
  }
  else {
    //Eyes Open
    fill(96, 35, 27);
    ellipse(x, x, w, h);
    ellipse(y, x, w, h);

    //Pupils
    fill(0, 0, 0);
    ellipse(x, x, 22, 25);  
    ellipse(y, x, 22, 25);

    //Mouth
    fill(234, 167, 167);
    arc(t, y, 50, 50, 0, 180);
  }

  fill(0, 0, 0);
  text("We will customize this text later on in the project to reflect your avatar.", 0, 50);

  //Directions for mouse press
  text("Click to see me blink", 200, 350);
}