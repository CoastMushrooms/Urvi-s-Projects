import java.util.Scanner;
public class uhOh
{
  Scanner keys = new Scanner(System.in);
  public uhOh()
  {
    //IntArray();
    madLibs();
  }
  
  
  public void madLibs()
  {
    System.out.println("Welcome to your greatest nightmare!");
    String [] prompts = new String []{"Proper Noun", "noun", "adjective", "verb", "adjective", "animal", "verb", "color", "verb (ending in ing)", "adverb (ending in ly)", "number", "measure of time", "color", "animal", "number", "silly word", "noun"};
    String [] responses = new String [prompts.length];
    
    for(int i = 0; i < prompts.length; i++)
    {
      System.out.print("Enter a " + prompts[i] + ": ");
      responses[i] = keys.nextLine();
    }
  
    System.out.println("This weekend I am going camping with " + responses[0] + ". I packed my lantern, sleeping bag, and " + responses[1] + ". I am so " + responses[2] + " to " + responses[3] + " in a tent. I am " + responses[4] + " we might see a " + responses[5] + ", they are kind of dangerous. We are going to hike, fish, and " + responses[6] + ". I have heard that the " + responses[7] + " lake is great for " + responses[8] + ". Then we will " + responses[9] + " hike through the forest for " + responses[10] + " " + responses[11] + ". If I see a " + responses[12] + " " + responses[13] + " while hiking, I am going to bring it home as a pet! At night we will tell " + responses[14] + " " + responses[15] + " stories and roast " + responses[16] + " around the campfire!!");
  }
  
  public void IntArray()
  {
    //declaring an int array
    int[] nums;
    int sum = 0;
    
    //initilize      needs a length
    nums = new int [50];//0s everywhere
    
    //nums = new int[]{11, 22, 33, 44, 55, 66, 77, 88, 99};//intializer list
    
    //fill the array
    for(int i = 0; i < nums.length; i++)
    {
      nums[i] = (int)(Math.random()*96 + 5);//*total possibilities  + starting point
      sum += nums[i];
    }
    
    //print the array
    System.out.println(nums);//can't print an array, only each index...
    
    for(int i = 0; i < nums.length; i++)
    {
      System.out.print(nums[i] + " ");//nums at index i
    }
    
    System.out.println("\nSum: " + sum);
  }
  
  public static void main(String [] args)
  {
    uhOh examples = new uhOh();
  }
}