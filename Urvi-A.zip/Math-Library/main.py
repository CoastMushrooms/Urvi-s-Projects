# Author: Urvi Akhouri
# Program Name: Math Library V3
# Description: The purpose of this project is to make a calculator
# Date: 03/13/23
# Version: 1.0

import math

disTance = lambda point1, point2, point3, point4: math.sqrt(math.pow(point1 - point2, 2) + math.pow(point3 - point4, 2))
heron = lambda s, a, b, c: math.sqrt(s * (s - a) * (s - b) * (s - c))
ctoF = lambda celsius: (celsius * 9 / 5) + 32
ftoC = lambda farenheit: (farenheit - 32) * 5 / 9
pythagLeg = lambda hypo, leg1: math.sqrt(math.pow(hypo, 2) - math.pow(leg1, 2))
pythagHypo = lambda leg1, leg2: math.sqrt(math.pow(leg1, 2) + math.pow(leg2, 2))

choice = 1
while choice != 0:
    option = int(input("What do you want to solve for:\n"
                       "1. Distance Formula\n"
                       "2. Heron’s Formula\n"
                       "3. Temperature Scale Conversion\n"
                       "4. Pythagorean Theorem\n"
                       "5. Exit\n\n"
                       "Enter here (Number Only): "))

    if option == 1:
        x1 = int(input("Enter the value of the first x coordinate: "))
        x2 = int(input("Enter the value of the second x coordinate: "))
        y1 = int(input("Enter the value of the first y coordinate: "))
        y2 = int(input("Enter the value of the second y coordinate: "))
        distance = disTance(x1, x2, y1, y2)
        print("The coordinates are (" + str(x1) + " , " + str(y1) + ") and (" + str(x2) + " , " + str(y2) + ")")
        print("The distance between the points is " + str(distance))
    elif option == 2:
        herA = int(input("Enter the length of the 1st side of the triangle: "))
        herB = int(input("Enter the length of the 2nd side of the triangle: "))
        herC = int(input("Enter the length of the 3rd side of the triangle: "))
        semiP = (herA + herB + herC)/2
        area = heron(semiP, herA, herB, herC)
        print("The area of the triangle is " + str(area))
    elif option == 3:
        option2 = int(input("What temperature conversion are you trying to solve for?\n"
                            "1. Farenheit to Celsius\n"
                            "2. Celsius to Farenheit\n\n"
                            "Enter here (Number Only): "))
        if option2 == 1:
            tempF = int(input("Enter the temperature in farenheit: "))
            newTemp = ftoC(tempF)
            print("The temperature in celsius is " + str(newTemp))
        if option2 == 2:
            tempC = int(input("Enter the temperature in celsius: "))
            newTemp = ctoF(tempC)
            print("The temperature in farenheit is " + str(newTemp))
    elif option == 4:
        option2 = int(input("What side are you trying to solve for?\n"
                            "1. Solve for Leg\n"
                            "2. Solve for Hypotenuse\n\n"
                            "Enter here (Number Only): "))
        if option2 == 1:
            pyA = int(input("Enter the length of leg A: "))
            pyC = int(input("Enter the length of the hypotenuse: "))
            pyB = pythagLeg(pyC, pyA)
            print("The length of the other leg is " + str(pyB))
        if option2 == 2:
            pyA = int(input("Enter the length of leg A: "))
            pyB = int(input("Enter the length of leg B: "))
            pyC = pythagHypo(pyA, pyB)
            print("The length of the hypotenuse " + str(pyC))
    elif option == 5:
        print("Thanks for your time. Goodbye.")
        choice = 0
    else:
        print("invalid choice message")