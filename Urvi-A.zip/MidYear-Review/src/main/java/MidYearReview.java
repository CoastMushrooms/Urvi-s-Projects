public class MidYearReview {

    public static void main(String [] args)
    {
        //One of the first things we did was learn how to display to the screen
        //also how to comment code with these //
        System.out.println("Hello!");
        System.out.println("Hello!");
        System.out.println("Hello!");
        System.out.println("Hello!");
        System.out.println("Hello!");
        System.out.println("Hello!");
        System.out.println("Hello!");
        
        MidYearReview run = new MidYearReview();
    }
    
    public MidYearReview()
    {
        /*
        * pretty quickly we learned to "escape" the "main" method
        * this method here is called a "constructor" and is the only method that doesn't require a return type
        * this fancy ***** thing is a way to make larger comments
        */
        System.out.println("You may remember then working on an ASCII Art project where we honed our skills with the \"escape\" character");
        System.out.println("Look at the next line of code - get rid of the // in order to call the escape method");
        escape();
        
        System.out.println("Next up we learned about a couple different variable types!");
        
        ints();
        doubles();
        booleans();
        Strings();
    }
    
    public void escape()
    {
        //void means this method is not allow to return any data
        //fix the next several lines of code to properly display an "image"
        System.out.println("              __");
        System.out.println("             /'{>");
        System.out.println("         ____) (____");
        System.out.println("       //--;\"  \";--\\\\");
        System.out.println("      ///////\\_/\\\\\\\\\\\\\"");
        System.out.println("             m m");
    }
    
    public void ints()
    {
        //every variable is declared in a similar way
        //type //name
        int number;
        System.out.println("Variables can store values");
        number = 7;
        System.out.println(number);
        
        System.out.println("They can also be alters - or, vary!");
        number--;//decrement
        System.out.println(number);
        number++;//increment
        System.out.println(number);
        
        number-=5;//decrement
        System.out.println(number);
        number+=100;//increment
        System.out.println(number);
        
        //set the value of number to your favorite number and print it out!
    }
    
    public void doubles()
    {
        //every variable is declared in a similar way
        //type //name
        double decimal;
        
        decimal = 5;
        System.out.println("Value of decimal " + decimal);
        
        //these can also go up and down and vary!
        decimal++;
        System.out.println("Value of decimal " + decimal);
        decimal--;
        System.out.println("Value of decimal " + decimal);
        
        decimal += 4.875;
        System.out.println("Value of decimal " + decimal);
        
        decimal -= 22.99999;
        System.out.println("Value of decimal " + decimal);
        
        double uhOh = (22.0/7.0);
        System.out.println("Pi is " + uhOh);
        
    }
    
    public void booleans()
    {
        //every variable is declared in a similar way
        //type //name
        boolean toggle = true;
        
        System.out.println("Booleans can only hold true or false (on/off)(yes/no)");
        System.out.println("toggle is now " + toggle);
        
        toggle = !toggle;
        System.out.println("toggle is now " + toggle);
        toggle = !toggle;
        System.out.println("toggle is now " + toggle);
        toggle = !toggle;
        System.out.println("toggle is now " + toggle);
        
        //make an 2 if/else statement to print: "The light is on" or "The light is off" based on the toggle boolean
        
        if(toggle)
        {
            System.out.println("The light is on");
        }
        else
        {
            System.out.println("The light is off");
        }
    }
    
    public void Strings()
    {
        //every variable is declared in a similar way
        //type //name
        String word;
        String fav;
        //the word "String" by the way has a capitol letter because it is not a primitive data type like: int, double, char, & boolean
        word = "COMPSCI!!";
        fav = "food";
        System.out.println(word);
        System.out.println("I love " + word);
        
        //create a new String variable and use is it in the following print statement
        
        
        System.out.println(fav + " is better than " + word);
    }
}