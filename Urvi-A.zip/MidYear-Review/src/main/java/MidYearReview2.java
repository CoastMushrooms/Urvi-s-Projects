import java.util.Scanner;
public class MidYearReview2 {

public static void main(String [] args)
{
  System.out.println("After learning about printing, and variables, and semicolons, and parentheses, and all that good intro Java stuff.....");
  
  MidYearReview2 run = new MidYearReview2();
}
  
  public MidYearReview2()
  {
    System.out.println("We dove into using scanners to grab user input and also using \"methods\" to organize our code.");
    //might need an import....
    Scanner keys = new Scanner(System.in);
    
    System.out.println("What's your name: ");
    String name = keys.nextLine();
    
    System.out.println("What's your favorite number: ");
    double num = keys.nextInt();
    
    
    //these methods must accept a single variable as a parameter!
    //I did "greeting()" you do the rest...
    greeting(name);
    doubleNum(num);
    halfNum(num);
    numPlus100(num);
    numMinus1000(num);
    
  }
  
  public void greeting(String name)
  {
    System.out.println("Hello " + name);
  }
  
  public void doubleNum(double num)
  {
    double dn = 2*num;
    System.out.println("Two times your favorite number is " + dn);
  }
  
  public void halfNum(double num)
  {
    double hn = num/2;
    System.out.println("Half your favorite number is " + hn);
  }
  
  public void numPlus100(double num)
  {
    double pn = num + 100;
    System.out.println("One hundred plus your favorite number is " + pn);
  }
  
  public void numMinus1000(double num)
  {
    double mn = num - 1000;
    System.out.println("One thousand minus your favorite number is " + mn);
  }
}