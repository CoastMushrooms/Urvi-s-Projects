import java.util.Scanner;

public class MidYearReview3 {

  //might need an import....
  Scanner keys = new Scanner(System.in);//global scanner useable throughout this file

  public static void main(String [] args)
  {
    MidYearReview3 run = new MidYearReview3();
  }

  public MidYearReview3()
  {
    System.out.println("Using methods breaks up the code into more digestable sections");
    System.out.println("Last review file used only void methods - let's get some return types going!");
    
    
    String name = getName();
    
    int num = getNum();
    
    System.out.println("Hello " + name + ", your favorite number is " + num);
    
    System.out.println("Let's print a couple different things based on your favorite number...");
    int choice = options();
    
    while(choice != -1)
    {
      if(choice == 1)
      {
        listNums(num);
      }

      else if(choice == 2)
      {
        multiplesOfNums(num);
      }

      else if(choice == 3)
      {
        multiplicationGrid(num);
      }

      else if(choice == 4)
      {
        isPrime(num);
      }

    choice = options();
    }
  }

  public String getName()
  {
    System.out.println("What's your name: ");
    return keys.nextLine();
  }
  
  public int getNum()
  {
    System.out.println("What's your favorite number: ");
    return keys.nextInt();
  }
  
  public int options()
  {
    System.out.print("\n1. List Nums up to fav\n2. List first 10 multiples of fav\n3. Print multiplication grid\n4. Determine if number is prime\nSelection(-1 to quit): ");
    return keys.nextInt();
  }
  
  public void listNums(int num)
  {
    for(int i = 1; i <= num; i++)
    {
    System.out.print(i + " ");
    }
  }

  public void multiplesOfNums(int num)
  {
    for(int i = 1; i <= 10; i ++)
    {
      System.out.print(i*num + " ");
    }
  }
//prints the first 10 multiples of your fav number (ex. 13, 26, 39, 52, 65, ...)

  public void multiplicationGrid(int num)
  {
    for(int i = 1; i <= num; i++)
    {
      for(int a = 1; a <= num; a++)
      {
        System.out.print(i*a + "\t");
      }
    System.out.print("\n");
    }
  }
//prints a nXn multiplication grid - should be formatted with tabs!

  public void isPrime(int num)
  {
    boolean primo = true;
    for (int i = 2; i < num; i++)
    {
      if(num%i == 0)
      {
        primo = false;
        i+=num;
      }
    }
  }

  if(primo)
  {
    System.out.println("Your number is prime");
  }

  else
  {
    System.out.println("Your number is not prime");
  }
  System.out.println("\n");
//use a boolean and a for loop to determine if your favorite number is prime
}