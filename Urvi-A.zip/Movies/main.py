import pandas as pd
import matplotlib.pyplot as plt

pd.set_option('display.max_columns', None)
pd.set_option('max_colwidth', None)

movieData = pd.read_csv('./rotten_tomatoes_movies.csv')
favMovie = "The Iron Giant"

print("My favorite movie is " + favMovie)

print("\nThe data for my favorite movie is:")
print("\n")

favMovieBooleanList = movieData["movie_title"] == favMovie

favMovieData = movieData.loc[favMovieBooleanList]

print(favMovieData)
print("\n\n")

animationMovieBooleanList = movieData["genres"].str.contains("Animation")

animationMovieData = movieData.loc[animationMovieBooleanList]

numOfMovies = animationMovieData.shape[0]

print("We will be comparing " + favMovie +
      " to other movies under the genre Animation in the data set.\n")
print("There are " + str(numOfMovies) + " movies under the category Animation.")

print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
input("Press enter to see more information about how " + favMovie +
      " compares to other movies in this genre.\n")

min = 0
print("The min audience rating of the data set is: " + str(min))
print(favMovie + " is rated [X] points higher than the lowest rated movie.")
print()

max = 0
print("The max audience rating of the data set is: " + str(max))
print(favMovie + " is rated [X] points lower than the highest rated movie.")
print()

mean = 0
print("The mean audience rating of the data set is: " + str(mean))
print(favMovie + " [is higher than/lower than/the same as] the mean movie rating.")

median = 0
print("The median audience rating of the data set is: " + str(median))
print(favMovie + " [is higher than/lower than/the same as] the median movie rating.")

print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
input("Press enter to see data visualizations.\n")

plt.grid(True)
plt.title("")
plt.xlabel("")
plt.ylabel("")

print(
  "According to the histogram, ..."
)
print("Close the graph by pressing the 'X' in the top right corner.")
print()

plt.show()

plt.grid(True)
plt.title("")
plt.xlabel("")
plt.ylabel("")
plt.xlim(0, 100)
plt.ylim(0, 100)

print(
  "According to the scatter plot, ..."
)
print()

print("Close the graph by pressing the 'X' in the top right corner.")

plt.show()

print("\nThank you for reading through my data analysis!")