# Author: Urvi Akhouri
# Program Name: My Cart
# Description: The purpose of this project is to be a cart
# Date: 04/24/23
# Version: 1.0

# variables
items = []
prices = []

# loop
while True:
    # meal choice
    choice = int(input("Please choose from the following options:\n"
                       "1. Entrees\n"
                       "2. Sides\n"
                       "3. Drinks\n"
                       "0. Check out\n\n"
                       "Enter your choice here: "))
    # if/elif/else for meals
    if choice == 1:
        entree = int(input("Please choose an entree:\n"
                           "1. Samosa - $7.00\n"
                           "2. Sushi - $8.00\n"
                           "3. Fish - $6.50\n\n"
                           "Enter your choice here: "))
        # info to lists
        if entree == 1:
            items.append("Samosa")
            prices.append(7.00)
        elif entree == 2:
            items.append("Sushi")
            prices.append(8.00)
        elif entree == 3:
            items.append("Fish")
            prices.append(6.50)
        else:
            # error message
            print("invalid choice.")

    elif choice == 2:
        side = int(input("Please choose a side:\n"
                         "1. Mozzarella Sticks - $3.00\n"
                         "2. Salad - $2.00\n"
                         "3. Pasta - $4.25\n\n"
                         "Enter your choice here: "))

        if side == 1:
            items.append("Mozzarella Sticks")
            prices.append(3.00)
        elif side == 2:
            items.append("Salad")
            prices.append(2.00)
        elif side == 3:
            items.append("Pasta")
            prices.append(4.25)
        else:
            print("invalid choice.")

    elif choice == 3:
        drink = int(input("Please choose a drink:\n"
                          "1. Cola - $1.00\n"
                          "2. Orange Juice - $2.50\n"
                          "3. Milkshake - $2.75\n\n"
                          "Enter your choice here: "))

        if drink == 1:
            items.append("Cola")
            prices.append(1.00)
        elif drink == 2:
            items.append("Orange Juice")
            prices.append(1.50)
        elif drink == 3:
            items.append("Milkshake")
            prices.append(2.75)
        else:
            print("invalid choice.")
    # check out
    elif choice == 0:
        # loop escape
        break

    else:
        print("invalid choice.")

# check out menu
print("Items ordered:")

# items and prices are listed
for i in range(len(items)):
    print(items[i], "$" + "{:.2f}".format(prices[i]))

# total cost
total_cost = sum(prices)
print("Total cost: $" + "{:.2f}".format(total_cost))
