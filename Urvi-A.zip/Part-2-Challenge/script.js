/* VARIABLES */

/* SETUP RUNS ONCE */
function setup() {
  //sets the screen size
  createCanvas(400, 400); 

  //sets the background color
  background(255,249,226);  
}

/* DRAW LOOP REPEATS */
function draw() {
  
  // Draw an ellipse
  ellipse(60, 320, 100, 150)

  // Draw a line
   line(85, 400, 30, 400)
  
  // Draw a rectangle 
  rectMode(CENTER)
  angleMode(DEGREES)
  rect(300, 200, 120, 40)
  // Draw an arc
  arc(320, 50, 100, 100, 0, 180)
  
  // Sign your name
  textSize(18) 
  text("Urvi", 50, 400)
  text("This is a piece of art we created to practice drawing shapes and text to a p5.js sketch.", 0, 50)

  textSize(15)
  text("art\npractice\ntext", 200, 200)
  // Add a short description

}