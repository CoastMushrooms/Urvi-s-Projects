import java.util.Scanner;
public class PiArea
{
  Scanner keys = new Scanner(System.in);
  
  public PiArea()
  {
    double times = 1000000;
    double count = 0;
    
    for(int j = 1; j < 100000; j++)
      {
      for(int i = 1; i <= times; i++)
      {
        double x = Math.random();
        double y = Math.random();
    
        double dist = Math.sqrt(x*x + y*y);
    
        if(dist < 1)
        {
          count++;
        }
      }
        
    double piCalc = 4*(count/(times*j));
    System.out.println(piCalc);
    }
  }
  
  public static void main(String [] args)
  {
    PiArea run = new PiArea();
  }
}
