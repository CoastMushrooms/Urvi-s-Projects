import java.util.Scanner;
public class QuickMethods
{
  Scanner key = new Scanner(System.in);
  String name;
  int num1;
  int num2;
  
  public QuickMethods()
  {
    enterName();
    num1 = enterNum();
    num2 = enterNum();
    
    printName();
    addNums();
    
    System.out.println(getName());
  }
  
  public void enterName()
  {
    System.out.println("Enter your name: ");
    name = key.nextLine();
  }
  
  public int enterNum()
  {
    System.out.println("Enter a number: ");
    int value = key.nextInt();
    return value;
  }
  
  public void addNums()
  {
    System.out.print(num1 + num2);
  }
  
  public void printName()
  {
    System.out.print(name);
  }
  
  public String getName()
  {
    return name;
  }
  
  public static void main (String [] args)
  {
    QuickMethods run = new QuickMethods();
  }
}
