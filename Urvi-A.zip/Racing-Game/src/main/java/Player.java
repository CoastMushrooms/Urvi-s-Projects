public class Player
{
   String racer;
   int xPos;

   public Player(String name)
   {
      racer = name;
      xPos = 100;
   }

   public void move()
   {
      xPos += (int)(Math.random()*50);
   }

   public void reset()
   {
      xPos = 100;
   }
}