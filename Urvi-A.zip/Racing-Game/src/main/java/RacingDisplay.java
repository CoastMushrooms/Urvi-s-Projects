import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class RacingDisplay
{
   JFrame frame;
   JPanel racers;

   public RacingDisplay()
   {
      frame = new JFrame("RACING!!!");
      frame.setSize(1800, 1000);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      racers = new Racers();
      frame.add(racers);
      frame.setVisible(true);
   }



   public static void main(String [] args)
   {
      RacingDisplay race = new RacingDisplay();
   }


   public class Racers extends JPanel
   {
      BufferedImage racer1;
      BufferedImage racer2;
      BufferedImage racer3;

      public Racers()
      {
         try
         {
            racer1 = ImageIO.read(new File("racer1.jpeg"));
            racer2 = ImageIO.read(new File("racer2.png"));
            racer3 = ImageIO.read(new File("racer3.jpg"));
         }
         catch(IOException e)
         {
            System.out.println("File not found!");
         }
         repaint();
      }

      public void paintComponent(Graphics g)
      {
         g.setColor(Color.RED);
         g.fillRect(0,0,frame.getWidth(),frame.getHeight());
         g.drawImage(racer1, 250, 150, null, null);
         g.drawImage(racer2, 250, 350, null, null);
         g.drawImage(racer3, 250, 550, null, null);

      }
   }
}