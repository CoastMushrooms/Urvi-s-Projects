import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class raceGame extends JPanel
{
   JFrame frame;
   BufferedImage racer1;

   public raceGame()
   {
      frame = new JFrame("RACING");
      frame.setSize(1800, 1000);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setVisible(true);

      try
      {
         racer1 = ImageIO.read(new File("demon"));
      }

      catch(IOException e)
      {
         System.out.println("File not found");
      }
   }

   public void paintComponent(Graphics g)
   {
      g.drawImage(racer1, 250, 250, null, null);
   }

   public static void main (String [] args)
   {
      raceGame run = new raceGame();
   }
}