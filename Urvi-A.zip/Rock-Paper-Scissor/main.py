# Author: Urvi Akhouri
# Program Name: Unit 4 Test
# Description: The purpose of this project is to play rock-paper-scissors
# Date: 02/06/23
# Version: 1.0

# random package is imported to be used
import random

# counter variable for while loop
replay = 1

# while loop to run program in
while replay == 1:
    # choice variable to choose game style
    choice1 = int(input("\nHow would you like to play Rock-Paper-Scissors?\n"
                        "1. Single Game\n"
                        "2. Series of Games\n"
                        "3. Exit\n"
                        "\nEnter here (Numbers Only): "))
    # if/elif/else statements to choose move
    if choice1 == 1:
        # input variable for options
        userChoice = int(input("\nWhat would you like to use?\n"
                               "1. Rock\n"
                               "2. Paper\n"
                               "3. Scissors\n"
                               "\nEnter here (Numbers Only): "))

        # if/else statements to choose game option
        if userChoice == 1:
            user = "Rock"
        elif userChoice == 2:
            user = "Paper"
        elif userChoice == 3:
            user = "Scissors"
        else:
            # option for other choice than listed being used
            print("\nOnly use the numbers mentioned.\n")

        # random import is used
        # move for computer is chosen
        cpuChoice = random.randint(1, 3)
        if cpuChoice == 1:
            cpu = "Rock"
        elif cpuChoice == 2:
            cpu = "Paper"
        else:
            cpu = "Scissors"

        # results of selection are chosen
        print("User: " + user + " | Computer: " + cpu)

        # matchups are compared
        # winner of games is decided
        if userChoice == 1 and cpuChoice == 2:
            print("\nI win!\n")
        elif userChoice == 1 and cpuChoice == 3:
            print("\nYou win!\n")
        elif userChoice == 2 and cpuChoice == 1:
            print("\nYou win!\n")
        elif userChoice == 2 and cpuChoice == 3:
            print("\nI win!\n")
        elif userChoice == 3 and cpuChoice == 1:
            print("\nI win!\n")
        elif userChoice == 3 and cpuChoice == 2:
            print("\nYou win!\n")
        else:
            print("\nDraw! Try Again.\n")

    # game amount is chosen by user
    elif choice1 == 2:
        games = int(input("\nHow many games do you want to play: "))
        if games < 0:
            # invalid amount for computer to play
            print("\ninvalid input message\n")
        elif games == 1:
            # other option can be used
            print("\nYou should have chosen that last question.\n")
        elif games % 2 == 0:
            # odd game amount needed for winner
            print("\nChoose an ODD number of games.\n")
        else:
            # number of wins and score variables is declared
            targetWins = games // 2 + 1
            userWins = 0
            cpuWins = 0

            # second while loop for games under certain amount
            while userWins < targetWins and cpuWins < targetWins:
                userChoice = int(input("What would you like to use?\n"
                                       "1. Rock\n"
                                       "2. Paper\n"
                                       "3. Scissors\n"
                                       "\nEnter here (Numbers Only): "))
                if userChoice == 1:
                    user = "Rock"
                elif userChoice == 2:
                    user = "Paper"
                elif userChoice == 3:
                    user = "Scissors"

                cpuChoice = random.randint(1, 3)
                if cpuChoice == 1:
                    cpu = "Rock"
                elif cpuChoice == 2:
                    cpu = "Paper"
                else:
                    cpu = "Scissors"

                print("User: " + user + "| Computer: " + cpu)

                if userChoice == 1 and cpuChoice == 2:
                    print("\nI win!\n")
                    cpuWins = cpuWins + 1
                    print("User Wins: " + str(userWins) + " | Computer Wins: " + str(cpuWins))
                elif userChoice == 1 and cpuChoice == 3:
                    print("\nYou win!\n")
                    userWins = userWins + 1
                    print("User Wins: " + str(userWins) + " | Computer Wins: " + str(cpuWins))
                elif userChoice == 2 and cpuChoice == 1:
                    print("\nYou win!\n")
                    userWins = userWins + 1
                    print("User Wins: " + str(userWins) + " | Computer Wins: " + str(cpuWins))
                elif userChoice == 2 and cpuChoice == 3:
                    print("\nI win!\n")
                    cpuWins = cpuWins + 1
                    print("User Wins: " + str(userWins) + " | Computer Wins: " + str(cpuWins))
                elif userChoice == 3 and cpuChoice == 1:
                    print("\nI win!\n")
                    cpuWins = cpuWins + 1
                    print("User Wins: " + str(userWins) + " | Computer Wins: " + str(cpuWins))
                elif userChoice == 3 and cpuChoice == 2:
                    print("\nYou win!\n")
                    userWins = userWins + 1
                    print("User Wins: " + str(userWins) + " | Computer Wins: " + str(cpuWins))
                else:
                    print("\nDraw! Try Again.\n")

                # winner is declared after comparing variable amounts
                if userWins > cpuWins and userWins == targetWins:
                    print("You win the match!")
                    # loop is broken
                    break

                elif cpuWins > userWins and cpuWins == targetWins:
                    print("I win the match!")
                    break
    # option response by computer to end loop
    elif choice1 == 3:
        # variable is changed to end loop
        replay = 0
        print("\nThanks for playing! See you again!")

    # wrong input is restarts choice
    else:
        print("\nOnly use the numbers mentioned.\n")
