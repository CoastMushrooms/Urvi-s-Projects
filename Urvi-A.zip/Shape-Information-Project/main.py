# Author: Urvi Akhouri
# Program Name: Shape Information Project
# Description: The purpose of this project is to determine the best shapes
# Date: 04/13/23
# Version: 1.0

from triangle import s
from triangle import aRea
from circle import radius1
from circle import arEa
from rectangle import areA

totalFencing = float(input("Enter the length of the fencing: "))
radius = radius1(totalFencing)
sqSide = totalFencing/4
triSide = totalFencing/3

S = s(triSide)
triArea = aRea(S, triSide)
sqArea = areA(sqSide)
cirArea = arEa(radius)

if triArea > cirArea and triArea > sqArea:
    print("The triangle has the largest area.")
    print("The area of the triangle would be {:.2f}".format(triArea))
    print("The area of the circle would be {:.2f}".format(cirArea))
    print("The area of the square would be {:.2f}".format(sqArea))
elif cirArea > triArea and cirArea > sqArea:
    print("The circle has the largest area.")
    print("The area of the circle would be {:.2f}".format(cirArea))
    print("The area of the triangle would be {:.2f}".format(triArea))
    print("The area of the square would be {:.2f}".format(sqArea))
elif sqArea > cirArea and sqArea > triArea:
    print("The square has the largest area.")
    print("The area of the square would be {:.2f}".format(sqArea))
    print("The area of the circle would be {:.2f}".format(cirArea))
    print("The area of the triangle would be {:.2f}".format(triArea))
elif triArea == sqArea > cirArea:
    print("The triangle and square have the same area")
    print("The area of the triangle would be {:.2f}".format(triArea))
    print("The area of the square would be {:.2f}".format(sqArea))
    print("The area of the circle would be {:.2f}".format(cirArea))
elif cirArea == sqArea > triArea:
    print("The circle and square have the same area")
    print("The area of the circle would be {:.2f}".format(cirArea))
    print("The area of the square would be {:.2f}".format(sqArea))
    print("The area of the triangle would be {:.2f}".format(triArea))
elif triArea == cirArea > sqArea:
    print("The triangle and circle have the same area")
    print("The area of the triangle would be {:.2f}".format(triArea))
    print("The area of the circle would be {:.2f}".format(cirArea))
    print("The area of the square would be {:.2f}".format(sqArea))
elif triArea == cirArea == sqArea:
    print("All the shapes have the same area.")
    print("The area of the triangle would be {:.2f}".format(triArea))
    print("The area of the square would be {:.2f}".format(sqArea))
    print("The area of the circle would be {:.2f}".format(cirArea))