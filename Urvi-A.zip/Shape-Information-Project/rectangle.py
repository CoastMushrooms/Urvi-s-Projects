import math

perm = lambda length, width : (2 * length) + (2 * width)
areA = lambda length: length * length
diag = lambda length, width : math.sqrt(math.pow(length, 2) + math.pow(width, 2))
areA2 = lambda length, width: length * width