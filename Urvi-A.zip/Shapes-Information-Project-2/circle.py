import math

diaM = lambda radius: 2 * radius
circum = lambda radius: 2 * math.pi * radius
arEa = lambda radius: math.pi * (math.pow(radius, 2))
radius1 = lambda circumference: circumference/(2 * math.pi)
radius2 = lambda area: math.sqrt((area/math.pi))