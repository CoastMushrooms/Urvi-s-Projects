# Author: Urvi Akhouri
# Program Name: Shape Information Project
# Description: The purpose of this project is to determine the best shapes
# Date: 04/13/23
# Version: 1.0

from circle import circum
from circle import arEa
from triangle import SS
from triangle import triareA
from rectangle import areA2

circRadius = int(input("Enter the radius of the circle: "))
triSides1 = int(input("Enter the length of one triangle side: "))
triSides2 = int(input("Enter the length of another triangle side: "))
triSides3 = int(input("Enter the length of the other triangle side: "))
rectSide1 = int(input("Enter the length of the rectangle: "))
rectSide2 = int(input("Enter the width of the rectangle: "))

triPerm = triSides1 + triSides2 + triSides3
rectPerm = (rectSide1 * 2) + (rectSide2 * 2)
rectArea = areA2(rectSide1, rectSide2)
circCircum = circum(circRadius)
circArea = arEa(circRadius)
triS = SS(triSides1, triSides2, triSides3)
triArea = triareA(triS, triSides1, triSides2, triSides3)

straightFence = (triPerm + rectPerm) * 5
curvedFence = circCircum * 7
totalFence = triPerm + rectPerm + circCircum
fenceCost = straightFence + curvedFence

grassTotal = rectArea + circArea + triArea
grassCost = grassTotal * 3.50

totalCost = grassCost + fenceCost

print("\n"
      "----------------------------------------------------------------------\n")

print("Total Fence Needed: {:.2f} meters".format(totalFence))
print("Total Cost of Fence: ${:.2f}".format(fenceCost))
print("Amount of Grass Needed: {:.2f} square meters".format(grassTotal))
print("Total Cost of Grass: ${:.2f}".format(grassCost))
print("Final Cost of Project: ${:.2f}".format(totalCost))

print("\n"
      "----------------------------------------------------------------------")