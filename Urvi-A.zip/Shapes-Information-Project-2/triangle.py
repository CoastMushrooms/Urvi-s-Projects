import math

s = lambda a: 1/2 * (3*a)
aRea = lambda s, a: math.sqrt(s*(3*(s - a)))
area2 = lambda h, base: (h * base)/2
triangle = lambda a, b, c: a + b > c and a + c > b and b + c > a

SS = lambda a, b, c: 1/2 * (a + b + c)
triareA = lambda s, a, b, c: math.sqrt(s*((s - a)*(s - b)*(s - c)))