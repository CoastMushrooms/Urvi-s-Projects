# Author: Urvi Akhouri
# Program Name: The Newlywed Games
# Description: The purpose of this project is to check compatibility
# Date: 05/08/23
# Version: 1.0

player1Answers = set()
player2Answers = set()

names = ("Saumya", "Kush")
topics = ("ice cream flavor", "color", "Disney movie", "band", "superhero")

print("{}'s turn to answer!".format(names[0]))
for question in topics:
    answer = input("\nWhat is {}'s favorite {}: ".format(names[1], question))
    player1Answers.add(answer)

print("{}'s turn for questions!".format(names[1]))
for question in topics:
    answer = input("\nWhat is your favorite {}: ".format(question))
    player2Answers.add(answer)

matches = player1Answers.intersection(player2Answers)

score = len(matches)
print("\nhe score for this round is {}: ".format(score))

player1Answers.clear()
player2Answers.clear()

print("{}'s turn for answers!".format(names[1]))
for question in topics:
    answer = input("\nWhat is {}'s favorite {}: ".format(names[0], question))
    player2Answers.add(answer)

print("{}'s turn to questions!".format(names[0]))
for question in topics:
    answer = input("\nWhat is your favorite {}: ".format(question))
    player1Answers.add(answer)

matches = player2Answers.intersection(player1Answers)

score2 = len(matches)
print("\nThe score for this round is {}: ".format(score2))

total = score + score2
print("The total score is {}!".format(total))