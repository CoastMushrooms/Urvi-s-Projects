def getBoard():
    row1 = [1, 2, 3]
    row2 = [4, 5, 6]
    row3 = [7, 8, 9]
    gameBoard = [row1, row2, row3]
    return gameBoard


def printBoard(board):
    print("")
    for row in board:
        gameRow = str()
        for slot in row:
            gameRow += str(slot) + " "
        print(gameRow)


def divideBoard(board):
    r1 = board[0]
    r2 = board[1]
    r3 = board[2]

    c1 = [board[0][0], board[1][0], board[2][0]]
    c2 = [board[0][1], board[1][1], board[2][1]]
    c3 = [board[0][2], board[1][2], board[2][2]]

    d1 = [board[0][0], board[1][1], board[2][2]]
    d2 = [board[0][2], board[1][1], board[2][0]]

    dividedBoard = [r1, r2, r3, c1, c2, c3, d1, d2]
    return dividedBoard


def checkSame(rcd):
    previous = rcd[0]
    for element in rcd:
        if previous != element:
            return False
        previous = element
    return True


def checkWin(board):
    dividedBoard = divideBoard(board)
    for rcd in dividedBoard:
        if checkSame(rcd):
            return True
    return False


def detWinner(board):
    dividedBoard = divideBoard(board)
    for rcd in dividedBoard:
        if checkSame(rcd):
            return rcd[0]


def validMove(board, slot):
    return 1 <= slot <= 9 and any(slot in row for row in board)


def placeToken(board, slot, token):
    for row in board:
        for i in range(len(row)):
            if row[i] == slot:
                row[i] = token


def getvalid():
    while True:
        try:
            slot = int(input("Choose a slot to play in: "))
            return slot
        except ValueError:
            print("invalid input. try again")