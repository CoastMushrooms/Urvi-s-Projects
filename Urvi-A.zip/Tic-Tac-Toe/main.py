# Author: Urvi Akhouri
# Program Name: Tic-Tac-Toe Functions
# Description: The purpose of this project is to make tic-tac-toe
# Date: 06/06/23
# Version: 1.0

import TTT
import random
import matplotlib.pyplot as plt

replay = 1
playerTokens = ['X', 'O']
xWins = 0
oWins = 0

while replay == 1:
    board = TTT.getBoard()
    turn = random.randint(0, 1)
    for x in range(9):
        if turn == 1:
            print("\nPlayer O's Turn")
            print("{}".format(TTT.printBoard(board)))
        else:
            print("\nPlayer X's Turn")
            print("{}".format(TTT.printBoard(board)))

        valid = False
        while not valid:
            slot = TTT.getvalid()
            valid = TTT.validMove(board, slot)

        TTT.placeToken(board, slot, playerTokens[turn])

        turn = 1 - turn

        if TTT.checkWin(board):
            winner = TTT.detWinner(board)
            if winner == 'X':
                xWins += 1
            if winner == 'O':
                oWins += 1
            break

    TTT.printBoard(board)
    print("X Wins: {}".format(xWins))
    print("O Wins: {}".format(oWins))

    replay = int(input("Wanna play again? Enter 1 for Yes and 2 for No: "))

    wins = [xWins, oWins]
    gamesPlayed = sum(wins)
    percent = [xWins / gamesPlayed, oWins / gamesPlayed]

    if gamesPlayed > 1:
        choice = input("Enter 'p' for pie chart or 'b' for bar chart: ")

        if choice == 'p':
            labels = ['Player X', 'Player O']
            explode = (0.1, 0)
            plt.pie(percent, labels=labels, explode=explode, autopct='%1.1f%%')
            plt.title("Percentage of Games Won")
            plt.show()
        elif choice == 'b':
            labels = ['Player X', 'Player O']
            plt.bar(labels, wins)
            plt.xlabel("Players")
            plt.ylabel("Wins")
            plt.title("Number of Games Won")
            plt.show()
        else:
            print("invalid choice. no graph for you")