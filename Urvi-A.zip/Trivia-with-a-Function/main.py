# Author: Urvi Akhouri
# Program Name: Trivia with a Function
# Description: The purpose of this project is to make trivia
# Date: 03/23/23
# Version: 1.0


def question1(answer1):
    score = 0
    if answer1 == "a":
        print("Incorrect. The answer is the FBI.")
        print("You have earned " + str(score) + " point(s)")
    elif answer1 == "b":
        print("Incorrect. The answer is the FBI.")
        print("You have earned " + str(score) + " point(s)")
    elif answer1 == "c":
        print("Correct. The answer is the FBI!")
        score += 1
        print("You have earned " + str(score) + " point(s)")
    elif answer1 == "d":
        print("Incorrect. The answer is the FBI.")
        print("You have earned " + str(score) + " point(s)")
    return score


def question2(answer2):
    score2 = 0
    if answer2 == "a":
        print("Correct. The answer is Jamais-vu!")
        score2 += 1
        print("You have earned " + str(score2) + " point(s)")
    elif answer2 == "b":
        print("Incorrect. The answer is Jamais-vu.")
        print("You have earned " + str(score2) + " point(s)")
    elif answer2 == "c":
        print("Incorrect. The answer is Jamais-vu.")
        print("You have earned " + str(score2) + " point(s)")
    elif answer2 == "d":
        print("Incorrect. The answer is Jamais-vu.")
        print("You have earned " + str(score2) + " point(s)")
    return score2


def question3(answer3):
    score3 = 0
    if answer3 == "a":
        print("Incorrect. The answer is 90 seconds.")
        print("You have earned " + str(score3) + " point(s)")
    elif answer3 == "b":
        print("Correct. The answer is 90 seconds!")
        score3 += 1
        print("You have earned " + str(score3) + " point(s)")
    elif answer3 == "c":
        print("Incorrect. The answer is 90 seconds.")
        print("You have earned " + str(score3) + " point(s)")
    elif answer3 == "d":
        print("Incorrect. The answer is 90 seconds.")
        print("You have earned " + str(score3) + " point(s)")
    return score3


count = 1

while count == 1:
  answer1 = input(
    "In order to track suspects, which major US law enforcement agency created the electronic surveillance tools Magic Lantern (a trojan horse keystroke logger) and CIPAV (a piece of spyware that tracks user location via digital methods)?\n\n"
    "a. The CIA\n"
    "b. The IRS\n"
    "c. The FBI\n"
    "d. The United States Program of Justice\n\n"
    "Enter here (Letter Only): ")
  num1 = question1(answer1)
  answer2 = input("What is the opposite of Déjà-vu?\n\n"
                  "a. Jamais-vu\n"
                  "b. Presque-vu\n"
                  "c. Déjà-pense?\n"
                  "d. Cerveau-vu\n"
                  "Enter here (Letter Only): ")
  num2 = question2(answer2)
  answer3 = input("How long is a moment?\n\n"
                  "a. 60 seconds\n"
                  "b. 90 seconds\n"
                  "c. 100 seconds\n"
                  "d. 75 seconds\n"
                  "Enter here (Letter Only): ")
  num3 = question3(answer3)
  totalScore = question1(answer1) + question2(answer2) + question3(answer3)
  print("Congrats, you're total score is " + str(totalScore))
  count = 0
